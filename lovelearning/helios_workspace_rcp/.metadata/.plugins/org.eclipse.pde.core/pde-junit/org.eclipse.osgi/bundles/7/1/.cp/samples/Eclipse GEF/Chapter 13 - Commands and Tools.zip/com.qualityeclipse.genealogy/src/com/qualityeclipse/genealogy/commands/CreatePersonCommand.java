package com.qualityeclipse.genealogy.commands;

import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.gef.commands.Command;

import com.qualityeclipse.genealogy.model.*;

/**
 * Command to add a person to the genealogy graph
 */
public class CreatePersonCommand extends Command
{
	private final GenealogyGraph graph;
	private final Person person;
	private final Rectangle box;

	public CreatePersonCommand(GenealogyGraph g, Person p, Rectangle box) {
		super("Create Person");
		this.graph = g;
		this.person = p;
		this.box = box;
	}
	
	/**
	 * Add the person to the graph at the specified location
	 */
	public void execute() {
		person.setLocation(box.x, box.y);
		person.setSize(box.width, box.height);
		graph.addPerson(person);
	}
	
	/**
	 * Remove the person from the graph
	 */
	public void undo() {
		graph.removePerson(person);
	}
}
