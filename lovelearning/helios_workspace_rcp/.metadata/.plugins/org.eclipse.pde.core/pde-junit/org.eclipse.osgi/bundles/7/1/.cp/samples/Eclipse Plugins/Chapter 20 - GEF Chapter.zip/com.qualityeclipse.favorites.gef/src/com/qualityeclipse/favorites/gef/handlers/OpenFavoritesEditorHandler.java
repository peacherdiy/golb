package com.qualityeclipse.favorites.gef.handlers;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.PartInitException;

import com.qualityeclipse.favorites.gef.Activator;
import com.qualityeclipse.favorites.gef.editors.FavoritesGEFEditor;
import com.qualityeclipse.favorites.gef.editors.FavoritesGEFEditorInput;
import com.qualityeclipse.favorites.model.FavoritesManager;

/**
 * Open the {@link FavoritesGEFEditor} if it is not already open.
 */
public class OpenFavoritesEditorHandler extends AbstractHandler
{
   public Object execute(ExecutionEvent event) throws ExecutionException {
      try {
         IEditorInput editorInput =
               new FavoritesGEFEditorInput(FavoritesManager.getManager());
         Activator.getDefault()
               .getWorkbench()
               .getActiveWorkbenchWindow()
               .getActivePage()
               .openEditor(editorInput, FavoritesGEFEditor.ID);
      }
      catch (PartInitException e) {
         e.printStackTrace();
      }
      return null;
   }
}
