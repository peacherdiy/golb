package com.qualityeclipse.favorites.gef.editors;

import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IPersistableElement;

import com.qualityeclipse.favorites.model.FavoritesManager;

/**
 * Provides the model to the editor, or in our case an instance of
 * {@link FavoritesManager} for our GEF editor.
 */
public class FavoritesGEFEditorInput
      implements IEditorInput
{
   private final FavoritesManager model;

   public FavoritesGEFEditorInput(FavoritesManager model) {
      this.model = model;
   }

   public FavoritesManager getModel() {
      return model;
   }

   /**
    * Return <code>false</code> because this model is not persisted as a file in
    * the workspace and should not appear in the "File Most Recently Used" menu.
    * 
    * @see org.eclipse.ui.IEditorInput#exists()
    */
   public boolean exists() {
      return false;
   }

   public ImageDescriptor getImageDescriptor() {
      return null;
   }

   public String getName() {
      return "Favorites GEF Editor";
   }

   /**
    * The favorites model is persisted using a different mechanism so return
    * <code>null</code>.
    * 
    * @see org.eclipse.ui.IEditorInput#getPersistable()
    */
   public IPersistableElement getPersistable() {
      return null;
   }

   public String getToolTipText() {
      return "Favorites GEF Editor";
   }

   @SuppressWarnings("unchecked")
   public Object getAdapter(Class adapter) {
      return null;
   }
}