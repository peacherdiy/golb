package com.qualityeclipse.genealogy.parts;

import java.util.*;

import org.eclipse.draw2d.IFigure;
import org.eclipse.gef.*;

import com.qualityeclipse.genealogy.figures.MarriageFigure;
import com.qualityeclipse.genealogy.model.*;
import com.qualityeclipse.genealogy.model.connection.*;

/**
 * The {@link EditPart} for the {@link Marriage} model object. This EditPart is
 * responsible for creating a visual representation for the model object and for updating
 * that visual representation as the model changes.
 */
public class MarriageEditPart extends GenealogyElementEditPart
{
	public MarriageEditPart(Marriage marriage) {
		setModel(marriage);
	}

	public Marriage getModel() {
		return (Marriage) super.getModel();
	}

	/**
	 * Create and return the figure representing this model object
	 */
	protected IFigure createFigure() {
		return new MarriageFigure(getModel().getYearMarried());
	}
	
	/**
	 * Answer a collection of connection model objects that originate from the receiver.
	 */
	protected List<GenealogyConnection> getModelSourceConnections() {
		Marriage model = getModel();
		ArrayList<GenealogyConnection> offspringList = new ArrayList<GenealogyConnection>();
		for (Person offspring : model.getOffspring())
			offspringList.add(new GenealogyConnection(offspring, model));
		return offspringList;
	}

	/**
	 * Answer a collection of connection model objects that terminate at the receiver.
	 */
	protected List<GenealogyConnection> getModelTargetConnections() {
		Marriage marriage = getModel();
		ArrayList<GenealogyConnection> marriageList = new ArrayList<GenealogyConnection>(1);
		Person husband = marriage.getHusband();
		if (husband != null)
			marriageList.add(new GenealogyConnection(husband, marriage));
		Person wife = marriage.getWife();
		if (wife != null)
			marriageList.add(new GenealogyConnection(wife, marriage));
		return marriageList;
	}

	protected void createEditPolicies() {
	}
}
