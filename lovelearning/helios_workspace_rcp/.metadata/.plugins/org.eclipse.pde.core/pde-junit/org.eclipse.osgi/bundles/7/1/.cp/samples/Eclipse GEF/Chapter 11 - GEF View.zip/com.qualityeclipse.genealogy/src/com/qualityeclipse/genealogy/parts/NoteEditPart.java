package com.qualityeclipse.genealogy.parts;

import org.eclipse.draw2d.IFigure;
import org.eclipse.gef.EditPart;

import com.qualityeclipse.genealogy.figures.NoteFigure;
import com.qualityeclipse.genealogy.model.Note;

/**
 * The {@link EditPart} for the {@link Note} model object. This EditPart is responsible
 * for creating a visual representation for the model object and for updating that visual
 * representation as the model changes.
 */
public class NoteEditPart extends GenealogyElementEditPart
{
	public NoteEditPart(Note note) {
		setModel(note);
	}

	public Note getModel() {
		return (Note) super.getModel();
	}

	/**
	 * Create and return the figure representing this model object
	 */
	protected IFigure createFigure() {
		return new NoteFigure(getModel().getText());
	}

	protected void createEditPolicies() {
	}
}
