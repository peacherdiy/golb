package com.qualityeclipse.genealogy.parts;

import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.gef.*;
import org.eclipse.gef.editparts.AbstractGraphicalEditPart;

import com.qualityeclipse.genealogy.model.GenealogyElement;

/**
 * Shared behavior for several related {@link EditPart} subclasses such as
 * {@link PersonEditPart}.
 */
public abstract class GenealogyElementEditPart extends AbstractGraphicalEditPart
{
	/**
	 * Update the figure based upon the current model state
	 */
	protected void refreshVisuals() {
		GenealogyElement m = (GenealogyElement) getModel();
		Rectangle bounds = new Rectangle(m.getX(), m.getY(), m.getWidth(), m.getHeight());
		((GraphicalEditPart) getParent()).setLayoutConstraint(this, getFigure(), bounds);
		super.refreshVisuals();
	}
}