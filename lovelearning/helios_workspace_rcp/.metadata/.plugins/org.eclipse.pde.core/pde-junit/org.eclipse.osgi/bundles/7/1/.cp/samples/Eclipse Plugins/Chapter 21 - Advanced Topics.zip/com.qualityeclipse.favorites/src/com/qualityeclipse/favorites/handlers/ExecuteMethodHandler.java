package com.qualityeclipse.favorites.handlers;

import java.lang.reflect.Method;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.jdt.core.Flags;
import org.eclipse.jdt.core.IMethod;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.handlers.HandlerUtil;

import com.qualityeclipse.favorites.FavoritesLog;
import com.qualityeclipse.favorites.util.ProjectClassLoader;

/**
 * The ExecuteMethodHandler obtains the selected Java method, loads the type
 * declaring the method, instantiates a new instance of that type, and prints
 * the result of executing the method to the Console view. For simplicity, the
 * selected method must be public with no arguments.
 */
public class ExecuteMethodHandler extends AbstractHandler
{
   public Object execute(ExecutionEvent event) throws ExecutionException {
      ISelection selection = HandlerUtil.getCurrentSelection(event);
      if (selection instanceof IStructuredSelection)
         System.out.println(executeMethod((IStructuredSelection) selection));
      return null;
   }

   // //////////////////////////////////////////////////////////////////////////
   //
   // Method Execution
   //
   // //////////////////////////////////////////////////////////////////////////

   /**
    * Execute the currently selected method if one is selected
    * 
    * @param selection
    *           the current selection
    * @return return a message, either an error message or a message indicating
    *         the result of the operation.
    */
   private String executeMethod(IStructuredSelection selection) {

      // Get the first selected element

      if (selection == null || selection.isEmpty())
         return "Nothing selected";
      Object element = selection.getFirstElement();
      if (!(element instanceof IMethod))
         return "No Java method selected";
      
      // Make sure that the selected method has the right signature
      
      IMethod method = (IMethod) element;
      try {
         if (!Flags.isPublic(method.getFlags()))
            return "Java method must be public";
      }
      catch (JavaModelException e) {
         FavoritesLog.logError(e);
         return "Failed to get method modifiers";
      }
      if (method.getParameterTypes().length != 0)
         return "Java method must have zero arguments";
      
      // Load the class containing the selected method
      
      IType type = method.getDeclaringType();
      String typeName = type.getFullyQualifiedName();
      ClassLoader loader = new ProjectClassLoader(type.getJavaProject());
      Class<?> c;
      try {
         c = loader.loadClass(typeName);
      }
      catch (ClassNotFoundException e) {
         FavoritesLog.logError(e);
         return "Failed to load: " + typeName;
      }
      
      // Instantiate the target object
      
      Object target;
      try {
         target = c.newInstance();
      }
      catch (Exception e) {
         FavoritesLog.logError(e);
         return "Failed to instantiate: " + typeName;
      }
      
      // Use reflection to obtain and execute the method
      
      Method m;
      try {
         m = c.getMethod(method.getElementName(), new Class[] {});
      }
      catch (Exception e) {
         FavoritesLog.logError(e);
         return "Failed to find method: " + method.getElementName();
      }
      Object result;
      try {
         result = m.invoke(target, new Object[] {});
      }
      catch (Exception e) {
         FavoritesLog.logError(e);
         return "Failed to invoke method: " + method.getElementName();
      }
      
      // Return a message containing the execution result
      
      return "Return value = " + result;
   }
}
