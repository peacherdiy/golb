package com.qualityeclipse.favorites.gef.commands;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.gef.commands.Command;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.dialogs.ResourceSelectionDialog;

import com.qualityeclipse.favorites.model.FavoritesManager;

public class FavoriteItemCreateCommand extends Command
{
   private final FavoritesManager manager;
   private Object object = null;

   public FavoriteItemCreateCommand(FavoritesManager favoritesManager) {
      this.manager = favoritesManager;
   }

   public void execute() {
      Shell shell = Display.getCurrent().getActiveShell();
      IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
      ResourceSelectionDialog dialog =
            new ResourceSelectionDialog(shell, root,
                  "Select a resource to add as a favorite item:");
      if (dialog.open() == Window.CANCEL)
         return;

      Object[] result = dialog.getResult();
      if (result.length == 0)
         return;
      if (!(result[0] instanceof IFile))
         return;

      object = result[0];
      redo();
   }

   public void redo() {
      manager.addFavorites(new Object[] { object });
   }

   public boolean canUndo() {
      return object != null;
   }

   public void undo() {
      manager.removeFavorites(new Object[] { object });
   }
}
