package com.qualityeclipse.genealogy.parts;

import java.util.*;

import org.eclipse.draw2d.*;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.editparts.AbstractGraphicalEditPart;

import com.qualityeclipse.genealogy.model.*;

/**
 * The {@link EditPart} for the {@link GenealogyGraph} model object. This EditPart is
 * responsible for creating the layer in which all other figures are placed and for
 * returning the collection of top level model objects to be displayed in that layer.
 */
public class GenealogyGraphEditPart extends AbstractGraphicalEditPart
{
	public GenealogyGraphEditPart(GenealogyGraph genealogyGraph) {
		setModel(genealogyGraph);
	}

	public GenealogyGraph getModel() {
		return (GenealogyGraph) super.getModel();
	}

	/**
	 * Construct and return the layer in which all other genealogy figures are displayed
	 */
	protected IFigure createFigure() {
		Figure figure = new FreeformLayer();
		figure.setBorder(new MarginBorder(3));
		figure.setLayoutManager(new FreeformLayout());
		return figure;
	}

	/**
	 * Return a collection of top level genealogy model objects to be displayed
	 */
	protected List<GenealogyElement> getModelChildren() {
		List<GenealogyElement> allObjects = new ArrayList<GenealogyElement>();
		allObjects.addAll(getModel().getMarriages());
		allObjects.addAll(getModel().getPeople());
		allObjects.addAll(getModel().getNotes());
		return allObjects;
	}

	protected void createEditPolicies() {
	}
}