package com.qualityeclipse.favorites.gef.editors;

import org.eclipse.gef.palette.CombinedTemplateCreationEntry;
import org.eclipse.gef.palette.MarqueeToolEntry;
import org.eclipse.gef.palette.PaletteContainer;
import org.eclipse.gef.palette.PaletteDrawer;
import org.eclipse.gef.palette.PaletteGroup;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.palette.PanningSelectionToolEntry;
import org.eclipse.gef.palette.ToolEntry;

import com.qualityeclipse.favorites.model.FavoriteResource;

public class FavoritesEditorPaletteFactory
{
   public static PaletteRoot createPalette() {
      PaletteRoot palette = new PaletteRoot();
      palette.add(createToolsGroup(palette));
      palette.add(createFavoritesDrawer());
      return palette;
   }

   private static PaletteContainer createToolsGroup(PaletteRoot palette) {
      PaletteGroup toolGroup = new PaletteGroup("Tools");

      ToolEntry tool = new PanningSelectionToolEntry();
      toolGroup.add(tool);
      palette.setDefaultEntry(tool);

      toolGroup.add(new MarqueeToolEntry());

      return toolGroup;
   }

   private static PaletteContainer createFavoritesDrawer() {
      PaletteDrawer componentsDrawer = new PaletteDrawer("Favorites Parts");

      FavoritesCreationFactory factory =
            new FavoritesCreationFactory(FavoriteResource.class);
      CombinedTemplateCreationEntry entry =
            new CombinedTemplateCreationEntry("Favorite Resource",
                  "Creates a favorite resource", FavoriteResource.class, factory, null,
                  null);
      componentsDrawer.add(entry);

      return componentsDrawer;
   }
}
