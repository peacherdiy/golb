package com.qualityeclipse.favorites.handlers;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IEditorReference;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IViewReference;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchPartReference;
import org.eclipse.ui.IWorkbenchPartSite;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.internal.PartSite;

public class ShowPartInfoHandler extends AbstractHandler
{
   public Object execute(ExecutionEvent event) throws ExecutionException {

      // Determine the active part.

      IWorkbenchPage activePage =
            PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();

      IWorkbenchPart activePart = activePage.getActivePart();

      // Search editor references.

      IEditorReference[] editorRefs = activePage.getEditorReferences();

      for (int i = 0; i < editorRefs.length; i++) {
         IEditorReference eachRef = editorRefs[i];
         if (eachRef.getEditor(false) == activePart) {
            printEditorInfo(eachRef, (IEditorPart) activePart);
         }
      }

      // Search view references.

      IViewReference[] viewRefs = activePage.getViewReferences();

      for (int i = 0; i < viewRefs.length; i++) {
         IViewReference eachRef = viewRefs[i];
         if (eachRef.getView(false) == activePart) {
            printViewInfo(eachRef, (IViewPart) activePart);
         }
      }
      return null;
   }

   private void printEditorInfo(IEditorReference editorRef, IEditorPart editor) {
      printPartInfo(editorRef, editor);
   }

   private void printViewInfo(IViewReference viewRef, IViewPart view) {
      printPartInfo(viewRef, view);
   }

   private void printPartInfo(IWorkbenchPartReference partRef, IWorkbenchPart part) {
      println(partRef.getTitle());
      println("  id = " + partRef.getId());
      IWorkbenchPartSite site = part.getSite();
      if (site instanceof PartSite) {
         String[] menuIds = ((PartSite) site).getContextMenuIds();
         if (menuIds != null) {
            for (int i = 0; i < menuIds.length; i++)
               println("  menuId = " + menuIds[i]);
         }
      }
   }

   public void println(String line) {
      System.out.println(line);
   }
}
