package com.qualityeclipse.favorites.gef.parts;

import com.qualityeclipse.favorites.gef.layouts.FavoritesLayout;

/**
 * Base class for those Favorites edit parts visible in the GEF canvas
 */
public abstract class AbstractFavoritesNodeEditPart extends
      AbstractFavoritesGraphicalEditPart
{
   /**
    * Answer the string used by {@link FavoritesLayout} to sort the figures.
    */
   public abstract String getSortKey();

   /**
    * Add the specified target connection
    * 
    * @param editPart
    *           the connection to be added
    * @return <code>true</code> if the connection was added, else
    *         <code>false</code>
    */
   public boolean addFavoritesTargetConnection(FavoriteConnectionEditPart editPart) {
      return false;
   }
   
   public boolean removeFavoritesTargetConnection(FavoriteConnectionEditPart conn) {
      return false;
   }
}
