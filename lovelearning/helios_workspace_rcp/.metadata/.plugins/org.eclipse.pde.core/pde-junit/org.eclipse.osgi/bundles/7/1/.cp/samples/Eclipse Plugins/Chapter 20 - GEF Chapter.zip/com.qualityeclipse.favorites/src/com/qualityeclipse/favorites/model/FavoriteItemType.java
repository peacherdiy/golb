package com.qualityeclipse.favorites.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.Platform;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.plugin.AbstractUIPlugin;

import com.qualityeclipse.favorites.FavoritesActivator;
import com.qualityeclipse.favorites.FavoritesLog;
import com.qualityeclipse.favorites.util.ImageCache;

/**
 * The <code>FavoriteItemType</code> object is returned by the
 * {@link IFavoriteItem#getType()} method and represents a type-safe enumeration
 * that can be used for sorting and storing Favorites objects. It has a
 * human-readable name associated with it for display purposes. Introducing the
 * FavoriteItemType rather than a simple String or int allows the sort order to
 * be separated from the human-readable name associated with a type of Favorites
 * object.
 */
public class FavoriteItemType
      implements Comparable<FavoriteItemType>
{
   private final IConfigurationElement configElement;
   private final String id;
   private final String name;
   private final int ordinal;
   private final String targetClassName;
   private FavoriteItemFactory factory;
   private ImageDescriptor imageDescriptor;

   public FavoriteItemType(IConfigurationElement configElem, int ordinal) {
      this.configElement = configElem;
      this.ordinal = ordinal;
      id = getAttribute(configElem, ATT_ID, null);
      name = getAttribute(configElem, ATT_NAME, id);
      targetClassName = getAttribute(configElem, ATT_TARGETCLASS, null);

      // Make sure that class is defined,
      // but don�t load it.
      getAttribute(configElem, ATT_CLASS, null);
   }

   private static String getAttribute(IConfigurationElement configElem, String name,
         String defaultValue) {
      String value = configElem.getAttribute(name);
      if (value != null)
         return value;
      if (defaultValue != null)
         return defaultValue;
      throw new IllegalArgumentException("Missing " + name + " attribute");
   }

   // //////////////////////////////////////////////////////////////////////////
   //
   // Accessors
   //
   // //////////////////////////////////////////////////////////////////////////

   private static final ImageCache imageCache = new ImageCache();

   /**
    * The unique identifier for this favorite item type
    */
   public String getId() {
      return id;
   }

   /**
    * The human readable name for this favorite item type
    */
   public String getName() {
      return name;
   }

   /**
    * Answer the image associated with this favorite item type or
    * <code>null</code> if none
    */
   public Image getImage() {
      return imageCache.getImage(getImageDescriptor());
   }

   /**
    * Answer the image description associated with this favorite item type or
    * <code>null</code> if none
    */
   public ImageDescriptor getImageDescriptor() {
      if (imageDescriptor != null)
         return imageDescriptor;
      String iconName = configElement.getAttribute(ATT_ICON);
      if (iconName == null)
         return null;
      IExtension extension = configElement.getDeclaringExtension();
      String extendingPluginId = extension.getNamespaceIdentifier();
      imageDescriptor =
            AbstractUIPlugin.imageDescriptorFromPlugin(extendingPluginId, iconName);
      return imageDescriptor;
   }

   /**
    * Answer a new favorite item wrappering the specified object
    * 
    * @param obj
    *           the object to be wrappered
    * @return the favorite item or <code>null</code> if it could not be
    *         wrappered by this type
    */
   public IFavoriteItem newFavorite(Object obj) {
      if (!isTarget(obj)) {
         return null;
      }
      FavoriteItemFactory factory = getFactory();
      if (factory == null) {
         return null;
      }
      return factory.newFavorite(this, obj);
   }

   /**
    * Determine if this object can be wrappered by this type
    * 
    * @param obj
    *           the object to be wrappered
    * @return <code>true</code> if it can be wrappered
    */
   private boolean isTarget(Object obj) {
      if (obj == null) {
         return false;
      }
      Class<?> clazz = obj.getClass();
      if (clazz.getName().equals(targetClassName)) {
         return true;
      }
      Class<?>[] interfaces = clazz.getInterfaces();
      for (int i = 0; i < interfaces.length; i++) {
         if (interfaces[i].getName().equals(targetClassName)) {
            return true;
         }
      }
      return false;
   }

   /**
    * Reinstantiate a favorite item from stored information
    * 
    * @param info
    *           the stored information
    * @return the favorite item or <code>null</code> if it could not be
    *         reinstantiated
    */
   public IFavoriteItem loadFavorite(String info) {
      FavoriteItemFactory factory = getFactory();
      if (factory == null) {
         return null;
      }
      return factory.loadFavorite(this, info);
   }

   /**
    * Answer the factory for instantiating items of this type
    * 
    * @return the factory or <code>null</code> if the factory itself could not
    *         be instantiated
    */
   private FavoriteItemFactory getFactory() {
      if (factory != null) {
         return factory;
      }
      try {
         factory =
               (FavoriteItemFactory) configElement.createExecutableExtension(ATT_CLASS);
      }
      catch (Exception e) {
         FavoritesLog.logError("Failed to instantiate factory: "
               + configElement.getAttribute(ATT_CLASS) + " in type: " + id
               + " in plugin: "
               + configElement.getDeclaringExtension().getNamespaceIdentifier(), e);
      }
      return factory;
   }

   public int compareTo(FavoriteItemType other) {
      return this.ordinal - other.ordinal;
   }

   /**
    * Dispose of any OS resources
    */
   public void dispose() {
      if (factory == null)
         return;
      factory.dispose();
      factory = null;
   }

   // //////////////////////////////////////////////////////////////////////////
   //
   // Single hard coded UNKNOWN item type
   //
   // //////////////////////////////////////////////////////////////////////////

   public static final FavoriteItemType UNKNOWN = new FavoriteItemType() {
      public IFavoriteItem newFavorite(Object obj) {
         return null;
      }

      public IFavoriteItem loadFavorite(String info) {
         return null;
      }
   };

   private FavoriteItemType() {
      this.id = "Unknown";
      this.ordinal = 0;
      this.name = "Unknown";
      this.configElement = null;
      this.targetClassName = "";
   }

   // //////////////////////////////////////////////////////////////////////////
   //
   // Static Accssors
   //
   // //////////////////////////////////////////////////////////////////////////

   // Constants used when reading favorite item type declarations

   private static final String TAG_ITEMTYPE = "itemType";
   private static final String ATT_ID = "id";
   private static final String ATT_NAME = "name";
   private static final String ATT_CLASS = "class";
   private static final String ATT_TARGETCLASS = "targetClass";
   private static final String ATT_ICON = "icon";

   /**
    * An array of favorite item types loaded from the "favorites" extension
    * point.
    */
   private static FavoriteItemType[] cachedTypes;

   /**
    * Answer an array of favorite item types, loading them from the "favorites"
    * extension point as necessary.
    * 
    * @return an array of favorite item types (not <code>null</code>)
    */
   public static FavoriteItemType[] getTypes() {
      if (cachedTypes != null)
         return cachedTypes;
      IExtension[] extensions =
            Platform.getExtensionRegistry().getExtensionPoint(
                  FavoritesActivator.PLUGIN_ID, "favorites").getExtensions();
      List<FavoriteItemType> found = new ArrayList<FavoriteItemType>(20);
      found.add(UNKNOWN);
      for (int i = 0; i < extensions.length; i++) {
         IConfigurationElement[] configElements =
               extensions[i].getConfigurationElements();
         for (int j = 0; j < configElements.length; j++) {
            FavoriteItemType proxy = parseType(configElements[j], found.size());
            if (proxy != null)
               found.add(proxy);
         }
      }
      cachedTypes =
            (FavoriteItemType[]) found.toArray(new FavoriteItemType[found.size()]);
      return cachedTypes;
   }

   /**
    * Parse a favorite item type declaration
    * 
    * @param configElement
    *           the configuration element containing the favorite item type
    *           declaration
    * @param ordinal
    *           the index of the favorite item type
    * @return the favorite item type or <code>null</code> if the parse has
    *         failed
    */
   private static FavoriteItemType parseType(IConfigurationElement configElement,
         int ordinal) {
      if (!configElement.getName().equals(TAG_ITEMTYPE))
         return null;
      try {
         return new FavoriteItemType(configElement, ordinal);
      }
      catch (Exception e) {
         String name = configElement.getAttribute(ATT_NAME);
         if (name == null)
            name = "[missing name attribute]";
         String msg =
               "Failed to load itemType named " + name + " in "
                     + configElement.getDeclaringExtension().getNamespaceIdentifier();
         FavoritesLog.logError(msg, e);
         return null;
      }
   }

   private static Map<String, FavoriteItemType> typeMap = null;

   /**
    * Answer the favorite item type that has the specified identifier
    * 
    * @param id
    *           the identifier
    * @return the type or <code>null</code> if none
    */
   public static FavoriteItemType getType(String id) {
      if (typeMap == null) {
         typeMap = new HashMap<String, FavoriteItemType>(cachedTypes.length);
         for (int i = 0; i < cachedTypes.length; i++) {
            FavoriteItemType eachType = cachedTypes[i];
            typeMap.put(eachType.getId(), eachType);
         }
      }
      return typeMap.get(id);
   }

   /**
    * Dispose of any OS resources. Must be called by the plugin before shutdown.
    */
   public static void disposeTypes() {
      if (cachedTypes == null)
         return;
      for (int i = 0; i < cachedTypes.length; i++)
         cachedTypes[i].dispose();
      imageCache.dispose();
      cachedTypes = null;
   }
}
