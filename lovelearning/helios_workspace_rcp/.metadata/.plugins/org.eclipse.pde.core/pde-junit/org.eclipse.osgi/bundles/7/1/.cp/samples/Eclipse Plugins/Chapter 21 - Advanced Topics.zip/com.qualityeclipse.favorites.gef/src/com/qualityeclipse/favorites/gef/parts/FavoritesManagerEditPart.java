package com.qualityeclipse.favorites.gef.parts;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.eclipse.core.resources.IResource;
import org.eclipse.draw2d.FreeformLayer;
import org.eclipse.draw2d.FreeformLayout;
import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.LayoutManager;
import org.eclipse.draw2d.Panel;
import org.eclipse.draw2d.geometry.Point;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPolicy;
import org.eclipse.gef.GraphicalEditPart;

import com.qualityeclipse.favorites.gef.layouts.FavoritesLayout;
import com.qualityeclipse.favorites.gef.policies.FavoritesLayoutEditPolicy;
import com.qualityeclipse.favorites.model.FavoritesManager;
import com.qualityeclipse.favorites.model.FavoritesManagerEvent;
import com.qualityeclipse.favorites.model.FavoritesManagerListener;
import com.qualityeclipse.favorites.model.IFavoriteItem;

/**
 * The edit part corresponding to the {@link FavoritesManager}.
 */
public class FavoritesManagerEditPart extends AbstractFavoritesGraphicalEditPart
{
   private final boolean editable;

   public FavoritesManagerEditPart(FavoritesManager manager, boolean editable) {
      setModel(manager);
      this.editable = editable;
   }

   public FavoritesManager getFavoritesManager() {
      return (FavoritesManager) getModel();
   }

   /**
    * Answer a collection of favorite items along with the resources referenced
    * by those favorite items.
    * 
    * @see org.eclipse.gef.editparts.AbstractEditPart#getModelChildren()
    */
   protected List<Object> getModelChildren() {
      IFavoriteItem[] items = getFavoritesManager().getFavorites();
      Collection<Object> result = new HashSet<Object>(items.length * 2);
      for (int i = 0; i < items.length; i++) {
         IFavoriteItem each = items[i];
         result.add(each);
         result.add(each.getAdapter(IResource.class));
      }
      return new ArrayList<Object>(result);
   }

   protected IFigure createFigure() {
      IFigure figure;
      if (editable) {
         figure = new FreeformLayer();
         figure.setLayoutManager(new FreeformLayout());
      }
      else {
         figure = new Panel();
         figure.setLayoutManager(new FavoritesLayout());
      }
      figure.setToolTip(createToolTipLabel());
      return figure;
   }

   protected void addChild(EditPart editPart, int index) {
      super.addChild(editPart, index);
      if (editable)
         return;
      AbstractFavoritesNodeEditPart child = (AbstractFavoritesNodeEditPart) editPart;
      IFigure childFigure = child.getFigure();
      LayoutManager layout = getFigure().getLayoutManager();
      String constraint = child.getSortKey();
      layout.setConstraint(childFigure, constraint);
   }

   private final FavoritesManagerListener modelListener = new FavoritesManagerListener() {
      public void favoritesChanged(FavoritesManagerEvent event) {
         if (editable)
            updateChildren(event);
         else
            refresh();
      }
   };

   /**
    * Update the model similar to {@link #refresh()}, but preserving current
    * z-order and placing new children randomly rather than at 0,0.
    * 
    * @param event
    *           the event describing the model change
    */
   private void updateChildren(FavoritesManagerEvent event) {

      // Build a map of model object to child edit parts

      Map<Object, EditPart> modelToEditPart =
            new HashMap<Object, EditPart>(getChildren().size());
      for (Iterator<?> iter = getChildren().iterator(); iter.hasNext();) {
         GraphicalEditPart child = (GraphicalEditPart) iter.next();
         modelToEditPart.put(child.getModel(), child);
      }

      // Remove child edit parts corresponding to removed model objects

      IFavoriteItem[] removed = event.getItemsRemoved();
      for (int i = 0; i < removed.length; i++) {

         // Remove the favorites item child if it exists

         IFavoriteItem item = removed[i];
         EditPart child = modelToEditPart.get(item);
         if (child == null)
            continue;
         removeChild(child);

         // Remove the associated resource child if it is not referenced

         Object res = item.getAdapter(IResource.class);
         child = modelToEditPart.get(res);
         if (child == null)
            continue;
         GraphicalEditPart rep = (GraphicalEditPart) child;
         if (rep.getTargetConnections().size() == 0)
            removeChild(child);
      }

      // Add child edit parts for new model objects

      IFavoriteItem[] added = event.getItemsAdded();
      for (int i = 0; i < added.length; i++) {

         // Add a favorites item child if necessary

         IFavoriteItem item = added[i];
         EditPart child = modelToEditPart.get(item);
         if (child != null)
            continue;
         child = createChild(item);
         setRandomChildLocation(child);
         addChild(child, getChildren().size());

         // Add a resource child if necessary

         Object res = item.getAdapter(IResource.class);
         child = modelToEditPart.get(res);
         if (child != null)
            continue;
         child = createChild(res);
         setRandomChildLocation(child);
         addChild(child, getChildren().size());
      }
   }

   private void setRandomChildLocation(EditPart child) {
      IFigure childFigure = ((GraphicalEditPart) child).getFigure();
      Random random = new Random();
      int x = random.nextInt() % 150 + 150;
      int y = random.nextInt() % 150 + 150;
      childFigure.setLocation(new Point(x, y));
      Rectangle constraint = childFigure.getBounds();
      LayoutManager layout = getFigure().getLayoutManager();
      layout.setConstraint(childFigure, constraint);
   }

   public void activate() {
      super.activate();
      if (editable)
         cleanupLayout();
      getFavoritesManager().addFavoritesManagerListener(modelListener);
   }

   /**
    * Perform initial layout for the editor by using the {@link FavoritesLayout}
    * class. This is accomplished by initializing the {@link FavoritesLayout}
    * with constraints for each child figure, asking the {@link FavoritesLayout}
    * to perform the layout, and then copying the bounds as constraints into the
    * primary layout manager.
    */
   private void cleanupLayout() {

      LayoutManager layout = new FavoritesLayout();
      for (Iterator<?> iter = getChildren().iterator(); iter.hasNext();) {
         AbstractFavoritesNodeEditPart child =
               (AbstractFavoritesNodeEditPart) iter.next();
         IFigure childFigure = child.getFigure();
         String constraint = child.getSortKey();
         layout.setConstraint(childFigure, constraint);
      }
      layout.layout(getFigure());

      layout = getFigure().getLayoutManager();
      for (Iterator<?> iter = getChildren().iterator(); iter.hasNext();) {
         AbstractFavoritesNodeEditPart child =
               (AbstractFavoritesNodeEditPart) iter.next();
         IFigure childFigure = child.getFigure();
         Rectangle constraint = childFigure.getBounds();
         layout.setConstraint(childFigure, constraint);
      }
   }

   public void deactivate() {
      getFavoritesManager().removeFavoritesManagerListener(modelListener);
      super.deactivate();
   }

   protected void createEditPolicies() {
      // handles constraint changes (e.g. moving and/or resizing)
      // of model elements and creation of new model elements
      installEditPolicy(EditPolicy.LAYOUT_ROLE, new FavoritesLayoutEditPolicy());
   }
}