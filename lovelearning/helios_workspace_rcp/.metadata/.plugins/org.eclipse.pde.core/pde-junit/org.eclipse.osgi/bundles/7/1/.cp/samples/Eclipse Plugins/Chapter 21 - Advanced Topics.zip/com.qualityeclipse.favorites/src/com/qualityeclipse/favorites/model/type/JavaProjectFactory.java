package com.qualityeclipse.favorites.model.type;

import org.eclipse.jdt.core.IJavaProject;

import com.qualityeclipse.favorites.model.FavoriteItemFactory;
import com.qualityeclipse.favorites.model.FavoriteItemType;
import com.qualityeclipse.favorites.model.FavoriteJavaElement;
import com.qualityeclipse.favorites.model.IFavoriteItem;

public class JavaProjectFactory extends FavoriteItemFactory
{
   public IFavoriteItem newFavorite(FavoriteItemType type, Object obj) {
      if (!(obj instanceof IJavaProject))
         return null;
      return new FavoriteJavaElement(type, (IJavaProject) obj);
   }

   public IFavoriteItem loadFavorite(FavoriteItemType type, String info) {
      return FavoriteJavaElement.loadFavorite(type, info);
   }
}
