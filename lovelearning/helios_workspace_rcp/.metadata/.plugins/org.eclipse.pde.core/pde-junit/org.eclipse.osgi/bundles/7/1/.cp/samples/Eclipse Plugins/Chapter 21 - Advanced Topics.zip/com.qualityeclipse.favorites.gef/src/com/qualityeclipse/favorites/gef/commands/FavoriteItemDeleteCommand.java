package com.qualityeclipse.favorites.gef.commands;

import org.eclipse.gef.commands.Command;

import com.qualityeclipse.favorites.model.FavoritesManager;
import com.qualityeclipse.favorites.model.IFavoriteItem;

public class FavoriteItemDeleteCommand extends Command
{
   private final FavoritesManager manager;
   private final Object object;

   public FavoriteItemDeleteCommand(FavoritesManager manager, IFavoriteItem item) {
      this.manager = manager;
      this.object = item.getAdapter(Object.class);
      setLabel("Delete " + item.getName());
   }

   public void execute() {
      redo();
   }

   public void redo() {
      manager.removeFavorites(new Object[] {object});
   }
   
   public void undo() {
      manager.addFavorites(new Object[] {object});
   }
}
