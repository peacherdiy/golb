package com.qualityeclipse.favorites.gef.views;

import org.eclipse.draw2d.ColorConstants;
import org.eclipse.draw2d.ConnectionLayer;
import org.eclipse.draw2d.ShortestPathConnectionRouter;
import org.eclipse.gef.LayerConstants;
import org.eclipse.gef.editparts.ScalableFreeformRootEditPart;
import org.eclipse.gef.ui.parts.ScrollingGraphicalViewer;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.part.ViewPart;

import com.qualityeclipse.favorites.gef.parts.FavoritesEditPartFactory;
import com.qualityeclipse.favorites.gef.parts.FavoritesManagerEditPart;
import com.qualityeclipse.favorites.model.FavoritesManager;

public class FavoritesGEFView extends ViewPart
{
   ScrollingGraphicalViewer graphicalViewer;

   public void createPartControl(Composite parent) {
      ScalableFreeformRootEditPart rootEditPart = new ScalableFreeformRootEditPart();

      graphicalViewer = new ScrollingGraphicalViewer();
      graphicalViewer.createControl(parent);
      graphicalViewer.getControl().setBackground(ColorConstants.listBackground);
      graphicalViewer.setRootEditPart(rootEditPart);
      graphicalViewer.setEditPartFactory(new FavoritesEditPartFactory(false));
      graphicalViewer.setContents(FavoritesManager.getManager());

      FavoritesManagerEditPart managerPart =
            (FavoritesManagerEditPart) rootEditPart.getChildren().get(0);
      ConnectionLayer connectionLayer =
            (ConnectionLayer) rootEditPart.getLayer(LayerConstants.CONNECTION_LAYER);
      connectionLayer.setConnectionRouter(new ShortestPathConnectionRouter(
            managerPart.getFigure()));
   }

   public void setFocus() {
   }
}