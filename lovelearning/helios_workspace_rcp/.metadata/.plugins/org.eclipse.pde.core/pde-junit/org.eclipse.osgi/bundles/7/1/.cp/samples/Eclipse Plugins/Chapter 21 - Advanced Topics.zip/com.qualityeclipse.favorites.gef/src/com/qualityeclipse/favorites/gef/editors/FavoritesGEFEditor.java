package com.qualityeclipse.favorites.gef.editors;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.draw2d.ConnectionLayer;
import org.eclipse.draw2d.ShortestPathConnectionRouter;
import org.eclipse.gef.DefaultEditDomain;
import org.eclipse.gef.GraphicalViewer;
import org.eclipse.gef.LayerConstants;
import org.eclipse.gef.editparts.ScalableFreeformRootEditPart;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.ui.actions.DeleteAction;
import org.eclipse.gef.ui.parts.GraphicalEditorWithFlyoutPalette;
import org.eclipse.ui.IEditorInput;

import com.qualityeclipse.favorites.gef.parts.FavoritesEditPartFactory;
import com.qualityeclipse.favorites.gef.parts.FavoritesManagerEditPart;
import com.qualityeclipse.favorites.model.FavoritesManager;

public class FavoritesGEFEditor extends GraphicalEditorWithFlyoutPalette
{
   public static final String ID = "com.qualityeclipse.favorites.gef.editor";

   private FavoritesManager model;

   public FavoritesGEFEditor() {
      setEditDomain(new DefaultEditDomain(this));
   }

   protected void setInput(IEditorInput input) {
      super.setInput(input);
      model = ((FavoritesGEFEditorInput) input).getModel();
   }

   protected void configureGraphicalViewer() {
      super.configureGraphicalViewer();
      GraphicalViewer viewer = getGraphicalViewer();
      viewer.setEditPartFactory(new FavoritesEditPartFactory(true));
      viewer.setRootEditPart(new ScalableFreeformRootEditPart());
   }

   /**
    * Initialize the graphic viewer and the connection layer so that connections
    * are routed around existing figures.
    * 
    * @see org.eclipse.gef.ui.parts.GraphicalEditorWithFlyoutPalette#initializeGraphicalViewer()
    */
   protected void initializeGraphicalViewer() {
      super.initializeGraphicalViewer();

      GraphicalViewer viewer = getGraphicalViewer();
      viewer.setContents(model);

      ScalableFreeformRootEditPart rootEditPart =
            (ScalableFreeformRootEditPart) viewer.getRootEditPart();
      FavoritesManagerEditPart managerPart =
            (FavoritesManagerEditPart) rootEditPart.getChildren().get(0);
      ConnectionLayer connectionLayer =
            (ConnectionLayer) rootEditPart.getLayer(LayerConstants.CONNECTION_LAYER);
      connectionLayer.setConnectionRouter(new ShortestPathConnectionRouter(
            managerPart.getFigure()));
   }

   /**
    * Our editor does not store content in a workspace file, so always return
    * false to prevent the user from being asked to save the editor content.
    * 
    * @see org.eclipse.gef.ui.parts.GraphicalEditor#isDirty()
    */
   public boolean isDirty() {
      return false;
   }

   /**
    * The editor's content is not stored in a workspace file and does not follow
    * the normal open - modify - save - close cycle so there is nothing to be
    * done by this method.
    * 
    * @see org.eclipse.ui.part.EditorPart#doSave(org.eclipse.core.runtime.IProgressMonitor)
    */
   public void doSave(IProgressMonitor monitor) {
      // do nothing
   }

   @SuppressWarnings("unchecked")
   public Object getAdapter(Class type) {
      if (type == FavoritesManager.class)
         return model;
      return super.getAdapter(type);
   }

   @SuppressWarnings("deprecation")
   public void deleteSelection() {
      getActionRegistry().getAction(DeleteAction.ID).run();
   }

   protected PaletteRoot getPaletteRoot() {
      return FavoritesEditorPaletteFactory.createPalette();
   }
}