package com.qualityeclipse.favorites.handlers;

import java.io.IOException;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.swt.SWT;
import org.eclipse.swt.program.Program;

import com.qualityeclipse.favorites.FavoritesLog;

/**
 * Trigger the default email client to open a window for composing a
 * new email. Prepopulate some of the fields such as recipient,
 * subject and body.
 */
public class OpenEmailHandler extends AbstractHandler
{
   private String recipient;
   private String subject;
   private String body;

   public OpenEmailHandler() {
      setRecipient("info@qualityeclipse.com");
      setSubject("Question");
      setBody("My question is ...\nSecond line\nThird line.");
   }

   public void setRecipient(String recipient) {
      this.recipient = recipient;
   }

   public void setSubject(String subject) {
      this.subject = subject;
   }

   public void setBody(String body) {
      this.body = body;
   }

   public Object execute(ExecutionEvent event) throws ExecutionException {

      // Determine the platform specific template

      String template;
      if (SWT.getPlatform().equals("win32")) {
         template = "mailto:${recipient}" + "?Subject=${subject}&Body=${body}";
      }
      else {
         // Put code here to test for various Linux email clients
         template = "netscape mailto:${recipient}" + "?Subject=${subject}&Body=${body}";
      }

      // Construct a mailSpec based upon the template

      String mailSpec = buildMailSpec(template);

      // Use the mailSpec to launch the email client

      if (mailSpec.startsWith("mailto:")) {
         Program.launch(mailSpec);
      }
      else {
         try {
            Runtime.getRuntime().exec(mailSpec);
         }
         catch (IOException e) {
            FavoritesLog.logError("Failed to open mail client: " + mailSpec, e);
         }
      }
      return null;
   }

   private String buildMailSpec(String template) {
      StringBuffer buf = new StringBuffer(1000);
      int start = 0;
      while (true) {
         int end = template.indexOf("${", start);
         if (end == -1) {
            buf.append(template.substring(start));
            break;
         }
         buf.append(template.substring(start, end));
         start = template.indexOf("}", end + 2);
         if (start == -1) {
            buf.append(template.substring(end));
            break;
         }
         String key = template.substring(end + 2, start);
         if (key.equalsIgnoreCase("recipient")) {
            buf.append(recipient);
         }
         else if (key.equalsIgnoreCase("subject")) {
            buf.append(subject);
         }
         else if (key.equalsIgnoreCase("body")) {
            appendBody(buf);
         }
         start++;
      }
      return buf.toString();
   }

   private void appendBody(StringBuffer buf) {
      if (body == null)
         return;
      int start = 0;
      while (true) {
         int end = body.indexOf('\n', start);
         if (end == -1) {
            buf.append(body.substring(start));
            return;
         }
         if (end > 0 && body.charAt(end - 1) == '\r')
            buf.append(body.substring(start, end - 1));
         else
            buf.append(body.substring(start, end));
         buf.append("%0A");
         start = end + 1;
      }
   }
}
