package com.qualityeclipse.favorites.gef.editors;

import org.eclipse.gef.ui.actions.ActionBarContributor;
import org.eclipse.ui.actions.ActionFactory;

public class FavoritesGEFEditorContributor extends ActionBarContributor
{
   protected void buildActions() {
   }

   protected void declareGlobalActionKeys() {
      addGlobalActionKey(ActionFactory.UNDO.getId());
      addGlobalActionKey(ActionFactory.REDO.getId());

      // the Edit > Delete command functionality is implemented
      // using the new command infrastructure
      // addGlobalActionKey(ActionFactory.DELETE.getId());

      addGlobalActionKey(ActionFactory.PRINT.getId());
      addGlobalActionKey(ActionFactory.SELECT_ALL.getId());
   }
}
