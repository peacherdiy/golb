package com.qualityeclipse.favorites.gef.parts;

import org.eclipse.draw2d.Label;
import org.eclipse.gef.editparts.AbstractGraphicalEditPart;

/**
 * Base class for all Favorites GEF edit parts
 */
public abstract class AbstractFavoritesGraphicalEditPart extends
      AbstractGraphicalEditPart
{
   protected Label createToolTipLabel() {
      Label toolTipLabel = new Label();
      String longName = getClass().getName();
      String shortName = longName.substring(longName.lastIndexOf('.') + 1);
      toolTipLabel.setText(shortName);
      return toolTipLabel;
   }
}