package com.qualityeclipse.genealogy.commands;

import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.gef.commands.Command;

import com.qualityeclipse.genealogy.model.*;

/**
 * Command to add a marriage to the genealogy graph
 */
public class CreateMarriageCommand extends Command
{
	private final GenealogyGraph graph;
	private final Marriage marriage;
	private final Rectangle box;

	public CreateMarriageCommand(GenealogyGraph g, Marriage m, Rectangle box) {
		super("Create Marriage");
		this.graph = g;
		this.marriage = m;
		this.box = box;
	}
	
	/**
	 * Add the person to the graph at the specified location
	 */
	public void execute() {
		marriage.setLocation(box.x, box.y);
		marriage.setSize(box.width, box.height);
		graph.addMarriage(marriage);
	}
	
	/**
	 * Remove the person from the graph
	 */
	public void undo() {
		graph.removeMarriage(marriage);
	}
}
