package com.qualityeclipse.favorites.gef.commands;

import java.util.Iterator;

import org.eclipse.core.resources.IResource;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.GraphicalEditPart;
import org.eclipse.gef.commands.Command;

import com.qualityeclipse.favorites.gef.parts.FavoritesManagerEditPart;
import com.qualityeclipse.favorites.model.IFavoriteItem;

public class AdjustConstraintCommand extends Command
{
   private FavoritesManagerEditPart manager;
   private Object model;
   private Rectangle newBounds, oldBounds;

   public AdjustConstraintCommand(GraphicalEditPart editPart, Rectangle contraint) {
      this.manager = (FavoritesManagerEditPart) editPart.getParent();
      this.model = editPart.getModel();
      this.newBounds = contraint;
      this.oldBounds = new Rectangle(editPart.getFigure().getBounds());
      setLabel(getOp(oldBounds, newBounds) + " " + getName(editPart));
   }

   private String getOp(Rectangle oldBounds, Rectangle newBounds) {
      if (oldBounds.getSize().equals(newBounds.getSize()))
         return "Move";
      return "Resize ";
   }

   private static String getName(EditPart editPart) {
      Object model = editPart.getModel();
      if (model instanceof IFavoriteItem)
         return ((IFavoriteItem) model).getName();
      if (model instanceof IResource)
         return ((IResource) model).getName();
      return "Favorites Element";
   }

   public void execute() {
      redo();
   }

   public void redo() {
      GraphicalEditPart editPart = getEditPart();
      if (editPart == null)
         return;
      manager.setLayoutConstraint(editPart, editPart.getFigure(), newBounds);
   }

   public void undo() {
      GraphicalEditPart editPart = getEditPart();
      if (editPart == null)
         return;
      manager.setLayoutConstraint(editPart, editPart.getFigure(), oldBounds);
   }

   private GraphicalEditPart getEditPart() {
      for (Iterator<?> iter = manager.getChildren().iterator(); iter.hasNext();) {
         GraphicalEditPart editPart = (GraphicalEditPart) iter.next();
         if (model.equals(editPart.getModel()))
            return editPart;
      }
      return null;
   }
}