package com.qualityeclipse.favorites.model.type;

import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaModelException;

import com.qualityeclipse.favorites.FavoritesLog;
import com.qualityeclipse.favorites.model.FavoriteItemFactory;
import com.qualityeclipse.favorites.model.FavoriteItemType;
import com.qualityeclipse.favorites.model.FavoriteJavaElement;
import com.qualityeclipse.favorites.model.IFavoriteItem;

public class JavaClassFactory extends FavoriteItemFactory
{
   public IFavoriteItem newFavorite(FavoriteItemType type, Object obj) {
      if (!(obj instanceof IType))
         return null;
      try {
         if (((IType) obj).isInterface())
            return null;
      }
      catch (JavaModelException e) {
         FavoritesLog.logError(e);
      }
      return new FavoriteJavaElement(type, (IType) obj);
   }

   public IFavoriteItem loadFavorite(FavoriteItemType type, String info) {
      return FavoriteJavaElement.loadFavorite(type, info);
   }
}
