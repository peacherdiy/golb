package com.qualityeclipse.favorites.model.type;

import org.eclipse.jdt.core.IPackageFragmentRoot;

import com.qualityeclipse.favorites.model.FavoriteItemFactory;
import com.qualityeclipse.favorites.model.FavoriteItemType;
import com.qualityeclipse.favorites.model.FavoriteJavaElement;
import com.qualityeclipse.favorites.model.IFavoriteItem;

public class JavaPackageRootFactory extends FavoriteItemFactory
{
   public IFavoriteItem newFavorite(FavoriteItemType type, Object obj) {
      if (!(obj instanceof IPackageFragmentRoot))
         return null;
      return new FavoriteJavaElement(type, (IPackageFragmentRoot) obj);
   }

   public IFavoriteItem loadFavorite(FavoriteItemType type, String info) {
      return FavoriteJavaElement.loadFavorite(type, info);
   }
}
