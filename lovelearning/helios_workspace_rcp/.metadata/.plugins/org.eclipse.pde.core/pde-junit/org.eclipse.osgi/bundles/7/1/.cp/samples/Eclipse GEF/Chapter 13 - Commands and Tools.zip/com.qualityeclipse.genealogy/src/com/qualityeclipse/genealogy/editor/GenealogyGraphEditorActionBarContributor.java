package com.qualityeclipse.genealogy.editor;

import org.eclipse.gef.ui.actions.*;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.ui.actions.*;

/**
 * Contributes actions for the current editor to the workbench.
 * This is covered in depth in the Eclipse Plug-ins book
 * and thus will not receive much attention in this GEF book.
 */
public class GenealogyGraphEditorActionBarContributor extends ActionBarContributor
{
	public GenealogyGraphEditorActionBarContributor() {
	}

	protected void buildActions() {
		addRetargetAction(new UndoRetargetAction());
		addRetargetAction(new RedoRetargetAction());
		addRetargetAction(new DeleteRetargetAction());
		addRetargetAction(new LabelRetargetAction(ActionFactory.SELECT_ALL.getId(), "Select All"));
	}
	
	public void contributeToToolBar(IToolBarManager toolBarManager) {
		toolBarManager.add(getAction(ActionFactory.UNDO.getId()));
		toolBarManager.add(getAction(ActionFactory.REDO.getId()));
	}

	protected void declareGlobalActionKeys() {
	}
}
