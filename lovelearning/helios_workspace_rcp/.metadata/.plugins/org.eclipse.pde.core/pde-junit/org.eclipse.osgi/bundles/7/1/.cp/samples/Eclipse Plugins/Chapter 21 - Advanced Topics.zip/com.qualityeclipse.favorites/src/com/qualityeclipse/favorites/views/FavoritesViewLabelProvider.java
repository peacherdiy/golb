package com.qualityeclipse.favorites.views;

import org.eclipse.jface.viewers.IColorProvider;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.IDecoratorManager;
import org.eclipse.ui.PlatformUI;

import com.qualityeclipse.favorites.model.IFavoriteItem;

class FavoritesViewLabelProvider extends LabelProvider
      implements ITableLabelProvider, IColorProvider
{
   final IDecoratorManager decorator;

   public FavoritesViewLabelProvider() {
      decorator = PlatformUI.getWorkbench().getDecoratorManager();
   }

   public void addListener(ILabelProviderListener listener) {
      decorator.addListener(listener);
      super.addListener(listener);
   }

   public void removeListener(ILabelProviderListener listener) {
      decorator.removeListener(listener);
      super.removeListener(listener);
   }

   public String getColumnText(Object obj, int index) {
      switch (index) {
      case 0: // Type column
         return "";
      case 1: // Name column
         String name;
         if (obj instanceof IFavoriteItem)
            name = ((IFavoriteItem) obj).getName();
         else if (obj != null)
            name = obj.toString();
         else
            name = "";
         String decorated = decorator.decorateText(name, obj);
         if (decorated != null)
            return decorated;
         return name;
      case 2: // Location column
         if (obj instanceof IFavoriteItem)
            return ((IFavoriteItem) obj).getLocation();
         return "";
      default:
         return "";
      }
   }

   public Image getColumnImage(Object obj, int index) {
      if ((index == 0) && (obj instanceof IFavoriteItem)) {
         Image image = ((IFavoriteItem) obj).getType().getImage();
         Image decorated = decorator.decorateImage(image, obj);
         if (decorated != null)
            return decorated;
         return image;
      }
      return null;
   }

   public Color getForeground(Object element) {
      if (element instanceof IFavoriteItem)
         return ((IFavoriteItem) element).getColor();
      return null;
   }

   public Color getBackground(Object element) {
      return null;
   }
}