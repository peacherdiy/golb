package com.qualityeclipse.favorites.preferences;

import org.eclipse.jface.preference.BooleanFieldEditor;
import org.eclipse.jface.preference.FieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.jface.util.PropertyChangeEvent;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import com.qualityeclipse.favorites.FavoritesActivator;

/**
 * This class represents a preference page that is contributed to the
 * Preferences dialog. By subclassing <samp>FieldEditorPreferencePage</samp>, we
 * can use the field support built into JFace that allows us to create a page
 * that is small and knows how to save, restore and apply itself.
 * <p>
 * This page is used to modify preferences only. They are stored in the
 * preference store that belongs to the main plug-in class. That way,
 * preferences can be accessed directly via the preference store.
 */
public class FavoritesPreferencePage extends FieldEditorPreferencePage
      implements IWorkbenchPreferencePage
{
   private BooleanFieldEditor namePrefEditor;
   private BooleanFieldEditor locationPrefEditor;
   private BooleanFieldEditor newVersionCheckEditor;

   public FavoritesPreferencePage() {
      super(GRID);
      setPreferenceStore(FavoritesActivator.getDefault().getPreferenceStore());
      setDescription("Favorites view column visibility:");
   }

   public void init(IWorkbench workbench) {
   }

   /**
    * Creates the field editors. Field editors are abstractions of the common
    * GUI blocks needed to manipulate various types of preferences. Each field
    * editor knows how to save and restore itself.
    */
   public void createFieldEditors() {
      namePrefEditor =
            new BooleanFieldEditor(
                  PreferenceConstants.FAVORITES_VIEW_NAME_COLUMN_VISIBLE,
                  "Show name column", getFieldEditorParent());
      addField(namePrefEditor);
      locationPrefEditor =
            new BooleanFieldEditor(
                  PreferenceConstants.FAVORITES_VIEW_LOCATION_COLUMN_VISIBLE,
                  "Show location column", getFieldEditorParent());
      addField(locationPrefEditor);
      newVersionCheckEditor =
            new BooleanFieldEditor(PreferenceConstants.FAVORITES_NEW_VERSION_CHECK_PREF,
                  "Periodically check for new version"
                        + " of Favorites product (simulated)", getFieldEditorParent());
      addField(newVersionCheckEditor);
   }

   protected void checkState() {
      super.checkState();
      if (!isValid())
         return;
      if (!namePrefEditor.getBooleanValue() && !locationPrefEditor.getBooleanValue()) {
         setErrorMessage("Must have at least one column visible");
         setValid(false);
      }
      else {
         setErrorMessage(null);
         setValid(true);
      }
   }

   public void propertyChange(PropertyChangeEvent event) {
      super.propertyChange(event);
      if (event.getProperty().equals(FieldEditor.VALUE)) {
         if (event.getSource() == namePrefEditor
               || event.getSource() == locationPrefEditor)
            checkState();
      }
   }
}