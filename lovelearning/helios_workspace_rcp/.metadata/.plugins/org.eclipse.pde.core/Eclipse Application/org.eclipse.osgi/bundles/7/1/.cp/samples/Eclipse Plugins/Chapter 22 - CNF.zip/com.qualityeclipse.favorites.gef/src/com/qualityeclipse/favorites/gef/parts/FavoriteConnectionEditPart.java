package com.qualityeclipse.favorites.gef.parts;

import java.util.Iterator;

import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.PolygonDecoration;
import org.eclipse.draw2d.PolylineConnection;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPartListener;
import org.eclipse.gef.editparts.AbstractConnectionEditPart;

import com.qualityeclipse.favorites.gef.model.FavoritesConnection;

/**
 * The edit part corresponding to the transient {@link FavoritesConnection}
 * object.
 */
public class FavoriteConnectionEditPart extends AbstractConnectionEditPart
{
   public FavoriteConnectionEditPart(FavoritesConnection connection) {
      setModel(connection);
   }

   public FavoritesConnection getFavoritesConnection() {
      return (FavoritesConnection) getModel();
   }

   /**
    * Extend the superclass method to decorate the line with an arrowhead
    * 
    * @see org.eclipse.gef.editparts.AbstractConnectionEditPart#createFigure()
    */
   protected IFigure createFigure() {
      PolylineConnection connection = (PolylineConnection) super.createFigure();
      connection.setTargetDecoration(new PolygonDecoration());
      return connection;
   }

   /**
    * Extend the superclass implementation to ensure that the connection target
    * has been properly set. If the target is not yet available, add a listener
    * waiting for the target to become available.
    * 
    * @see org.eclipse.gef.editparts.AbstractGraphicalEditPart#activate()
    */
   public void activate() {
      super.activate();
      final EditPart manager = (EditPart) getParent().getChildren().get(0);
      for (Iterator<?> iter = manager.getChildren().iterator(); iter.hasNext();) {
         AbstractFavoritesNodeEditPart child = (AbstractFavoritesNodeEditPart) iter.next();
         if (child.addFavoritesTargetConnection(this))
            return;
      }
      manager.addEditPartListener(new EditPartListener.Stub() {
         public void childAdded(EditPart editPart, int index) {
            AbstractFavoritesNodeEditPart child = (AbstractFavoritesNodeEditPart) editPart;
            if (child.addFavoritesTargetConnection(FavoriteConnectionEditPart.this))
               manager.removeEditPartListener(this);
         }
      });
   }
   
   public void deactivate() {
      final EditPart manager = (EditPart) getParent().getChildren().get(0);
      for (Iterator<?> iter = manager.getChildren().iterator(); iter.hasNext();) {
         AbstractFavoritesNodeEditPart child = (AbstractFavoritesNodeEditPart) iter.next();
         if (child.removeFavoritesTargetConnection(this))
            break;
      }
      super.deactivate();
   }

   protected void createEditPolicies() {
      // none
   }
}