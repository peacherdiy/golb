package com.qualityeclipse.favorites.model.type;

import org.eclipse.core.resources.IFile;

import com.qualityeclipse.favorites.model.FavoriteItemFactory;
import com.qualityeclipse.favorites.model.FavoriteItemType;
import com.qualityeclipse.favorites.model.FavoriteResource;
import com.qualityeclipse.favorites.model.IFavoriteItem;

/**
 * A factories that instantiate favorite items wrappering files.
 */
public class FileFactory extends FavoriteItemFactory
{
   /**
    * Answer a new favorite item wrappering the specified object
    * 
    * @param type
    *           the favorite item type
    * @param obj
    *           the object to be wrappered
    * @return the favorite item or <code>null</code> if it could not be
    *         wrappered by this type
    */
   public IFavoriteItem newFavorite(FavoriteItemType type, Object obj) {
      if (!(obj instanceof IFile))
         return null;
      return new FavoriteResource(type, (IFile) obj);
   }

   /**
    * Reinstantiate a favorite item from stored information
    * 
    * @param type
    *           the favorite item type
    * @param info
    *           the stored information
    * @return the favorite item or <code>null</code> if it could not be
    *         reinstantiated
    */
   public IFavoriteItem loadFavorite(FavoriteItemType type, String info) {
      return FavoriteResource.loadFavorite(type, info);
   }
}
