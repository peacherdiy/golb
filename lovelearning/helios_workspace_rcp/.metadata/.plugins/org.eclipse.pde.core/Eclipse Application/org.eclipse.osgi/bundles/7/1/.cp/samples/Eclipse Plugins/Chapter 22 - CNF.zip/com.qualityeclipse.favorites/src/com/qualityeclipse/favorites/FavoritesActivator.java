package com.qualityeclipse.favorites;

import java.io.File;
import java.net.URL;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.IAdapterManager;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.preferences.ConfigurationScope;
import org.eclipse.core.runtime.preferences.IEclipsePreferences;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.osgi.service.datalocation.Location;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;
import org.osgi.framework.Version;
import org.osgi.service.prefs.BackingStoreException;
import org.osgi.service.prefs.Preferences;

import com.qualityeclipse.favorites.jobs.NewVersionCheckJob;
import com.qualityeclipse.favorites.model.BasicFavoriteItem;
import com.qualityeclipse.favorites.model.FavoriteAdapterFactory;
import com.qualityeclipse.favorites.model.FavoriteItemType;
import com.qualityeclipse.favorites.model.FavoritesManager;

/**
 * The activator class controls the plug-in life cycle
 */
public class FavoritesActivator extends AbstractUIPlugin
{

   // The plug-in ID
   public static final String PLUGIN_ID = "com.qualityeclipse.favorites";

   // The shared instance
   private static FavoritesActivator plugin;

   // The configuration preferences
   private IEclipsePreferences configPrefs;

   /**
    * The adapter factory for translating resources and java elements into
    * favorites objects.
    */
   private FavoriteAdapterFactory favoriteAdapterFactory;

   /**
    * The constructor
    */
   public FavoritesActivator() {
   }

   /**
    * This method is called upon plug-in activation.
    */
   public void start(BundleContext context) throws Exception {
      super.start(context);
      plugin = this;

      // Register the adapter factory

      favoriteAdapterFactory = new FavoriteAdapterFactory();
      IAdapterManager mgr = Platform.getAdapterManager();
      mgr.registerAdapters(favoriteAdapterFactory, IResource.class);
      mgr.registerAdapters(favoriteAdapterFactory, IJavaElement.class);

      // Start a version check

      NewVersionCheckJob.startup();
   }

   /**
    * This method is called when the plug-in is stopped.
    */
   public void stop(BundleContext context) throws Exception {

      // Stop any version check

      NewVersionCheckJob.shutdown();

      // Unregister the adapter factory

      Platform.getAdapterManager().unregisterAdapters(favoriteAdapterFactory);
      favoriteAdapterFactory = null;

      // Save Favorites information

      FavoriteItemType.disposeTypes();
      FavoritesManager.getManager().saveFavorites();
      FavoritesManager.shutdown();

      // Save Favorites information

      saveConfigPrefs();

      // Dispose any cached colors

      BasicFavoriteItem.disposeColors();

      // Stop bundle

      plugin = null;
      super.stop(context);
   }

   /**
    * Returns the shared instance
    */
   public static FavoritesActivator getDefault() {
      return plugin;
   }

   /**
    * Returns an image descriptor for the image file at the given plug-in
    * relative path
    * 
    * @param path
    *           the path
    * @return the image descriptor
    */
   public static ImageDescriptor getImageDescriptor(String path) {
      return imageDescriptorFromPlugin(PLUGIN_ID, path);
   }

   /**
    * Answer the configuration location for this plug-in
    * 
    * @return the plugin's config directory (not <code>null</code>)
    */
   public File getConfigDir() {
      Location location = Platform.getConfigurationLocation();
      if (location != null) {
         URL configURL = location.getURL();
         if (configURL != null && configURL.getProtocol().startsWith("file")) {
            return new File(configURL.getFile(), PLUGIN_ID);
         }
      }
      // If the configuration directory is read-only,
      // then return an alternate location
      // rather than null or throwing an Exception.
      return getStateLocation().toFile();
   }

   /**
    * Answer the configuration preferences shared among multiple workspaces.
    * 
    * @return the configuration preferences or <code>null</code> if the
    *         configuration directory is read-only or unspecified.
    */
   public Preferences getConfigPrefs() {
      if (configPrefs == null)
         configPrefs = new ConfigurationScope().getNode(PLUGIN_ID);
      return configPrefs;
   }

   /**
    * Save the configuration preferences if they have been loaded
    */
   public void saveConfigPrefs() {
      if (configPrefs != null) {
         try {
            configPrefs.flush();
         }
         catch (BackingStoreException e) {
            e.printStackTrace();
         }
      }
   }

   /**
    * Return the plug-in's version
    */
   public Version getVersion() {
      return new Version((String) getBundle().getHeaders().get(
            org.osgi.framework.Constants.BUNDLE_VERSION));
   }

   public static boolean isEarlyStartupDisabled() {
      String plugins = PlatformUI.getPreferenceStore().getString(
      /*
       * Copy constant out of internal Eclipse interface
       * IPreferenceConstants.PLUGINS_NOT_ACTIVATED_ON_STARTUP so that we are
       * not accessing internal type.
       */
      "PLUGINS_NOT_ACTIVATED_ON_STARTUP");
      return plugins.indexOf(PLUGIN_ID) != -1;
   }
}
