package com.qualityeclipse.favorites.jobs;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Preferences;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.Preferences.PropertyChangeEvent;
import org.eclipse.core.runtime.jobs.Job;

import com.qualityeclipse.favorites.FavoritesActivator;
import com.qualityeclipse.favorites.preferences.PreferenceConstants;

/**
 * Periodically check for the availability of a newer version. Rather
 * than interrupt the user, we want to perform this check in the
 * background and provide the user with non-intrusive progress
 * information as the operation proceeds.
 */
public class NewVersionCheckJob extends Job
{
   private NewVersionCheckJob(String name) {
      super(name);
   }
   
   /**
    * Simulate job execution and return execution status
    */
   protected IStatus run(IProgressMonitor monitor) {
      // Simulate check for new version.
      monitor.beginTask("check for new version", 20);
      for (int i = 20; i > 0; --i) {
         monitor.subTask("seconds left = " + i);
         try {
            Thread.sleep(1000);
         } catch (InterruptedException e) {
            // Ignored.
         }
         monitor.worked(1);
      }
      monitor.done();
      // Reschedule job to execute in 2 minutes.
      schedule(120000);
      return Status.OK_STATUS;
   }
   
   ////////////////////////////////////////////////////////////////////////////
   //
   // Property Listener and job scheduling
   //
   ////////////////////////////////////////////////////////////////////////////
   
   private static final String JOB_NAME =
      "Favorites check for new version";

   private static NewVersionCheckJob job = null;

   public boolean shouldSchedule() {
      return equals(job);
   }

   private static final Preferences preferences = 
      FavoritesActivator.getDefault().getPluginPreferences();

   private static final Preferences.IPropertyChangeListener
      propertyListener = new Preferences.IPropertyChangeListener() {
         public void propertyChange(PropertyChangeEvent event) {
            update();
         }
      };

   private static void update() {
      if (preferences.getBoolean(
         PreferenceConstants.FAVORITES_NEW_VERSION_CHECK_PREF)) 
      {
         if (job == null) {
            job = new NewVersionCheckJob(JOB_NAME);
            // setUser true to show progress dialog or false for system job
            // job.setUser(true);
            job.schedule();
         }
      }
      else {
         if (job != null) {
            job.cancel();
            job = null;
         }
      }
   }
   
   public static void startup() {
      preferences.addPropertyChangeListener(propertyListener);
      update();
   }

   public static void shutdown() {
      preferences.removePropertyChangeListener(propertyListener);
   }
}
