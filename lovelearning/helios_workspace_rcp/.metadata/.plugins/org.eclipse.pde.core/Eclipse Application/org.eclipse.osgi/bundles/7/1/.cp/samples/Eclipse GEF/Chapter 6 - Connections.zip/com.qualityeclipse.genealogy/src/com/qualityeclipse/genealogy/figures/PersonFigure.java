package com.qualityeclipse.genealogy.figures;

import org.eclipse.draw2d.*;
import org.eclipse.draw2d.geometry.*;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Pattern;
import org.eclipse.swt.widgets.Display;

import com.qualityeclipse.genealogy.listener.FigureMover;

/**
 * A custom figure for the GenealogyView displaying a person's information
 */
public class PersonFigure extends Figure {

	public static final Image MALE = new Image(Display.getCurrent(),
			PersonFigure.class.getResourceAsStream("male.png"));
	public static final Image FEMALE = new Image(Display.getCurrent(),
			PersonFigure.class.getResourceAsStream("female.png"));
	
	public PersonFigure(String name, Image image, int birthYear, int deathYear) {
		final ToolbarLayout layout = new ToolbarLayout();
		layout.setSpacing(1);
		setLayoutManager(layout);
		setPreferredSize(100, 100);
		setBorder(new CompoundBorder(
			new LineBorder(1),
			new MarginBorder(2, 2, 2, 2)));
		
		// Display the image to the left of the name/date
		IFigure imageNameDates = new Figure();
		final GridLayout gridLayout = new GridLayout(2, false);
		gridLayout.marginHeight = 0;
		gridLayout.marginWidth = 0;
		gridLayout.horizontalSpacing = 1;
		imageNameDates.setLayoutManager(gridLayout);
		add(imageNameDates);
		imageNameDates.add(new ImageFigure(image));
		
		// Display the name and date to right of image
		IFigure nameDates = new Figure();
		nameDates.setLayoutManager(new ToolbarLayout());
		imageNameDates.add(nameDates, new GridData(GridData.FILL_HORIZONTAL));
		nameDates.add(new Label(name));

		// Display the year of birth and death
		String datesText = birthYear + " -";
		if (deathYear != -1)
			datesText += " " + deathYear;
		nameDates.add(new Label(datesText)); 
		
		new FigureMover(this);
	}

	public void paintFigure(Graphics graphics) {
		Rectangle r = getBounds();
		graphics.setBackgroundPattern(new Pattern(Display.getCurrent(), r.x,
				r.y, r.x + r.width, r.y + r.height, ColorConstants.white,
				ColorConstants.lightGray));
		graphics.fillRectangle(r);
	}
}
