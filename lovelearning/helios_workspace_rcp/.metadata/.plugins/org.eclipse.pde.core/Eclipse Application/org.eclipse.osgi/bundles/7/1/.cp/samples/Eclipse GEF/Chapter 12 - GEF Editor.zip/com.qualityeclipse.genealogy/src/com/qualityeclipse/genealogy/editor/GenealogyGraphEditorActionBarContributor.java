package com.qualityeclipse.genealogy.editor;

import org.eclipse.gef.ui.actions.ActionBarContributor;

/**
 * Contributes actions for the current editor to the workbench.
 * This is covered in depth in the Eclipse Plug-ins book
 * and thus will not receive much attention in this GEF book.
 */
public class GenealogyGraphEditorActionBarContributor extends ActionBarContributor
{
	public GenealogyGraphEditorActionBarContributor() {
	}

	protected void buildActions() {
	}

	protected void declareGlobalActionKeys() {
	}
}
