package com.qualityeclipse.favorites.handlers;

import java.net.MalformedURLException;
import java.net.URL;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.browser.IWebBrowser;
import org.eclipse.ui.browser.IWorkbenchBrowserSupport;
import org.eclipse.ui.handlers.HandlerUtil;

import com.qualityeclipse.favorites.FavoritesLog;

/**
 * Show a web page in a browser
 */
public class OpenWebPageHandler extends AbstractHandler
{
   public Object execute(ExecutionEvent event) throws ExecutionException {

      // Show a page in an external web browser
      // Program.launch("http://www.qualityeclipse.com");

      // Show a page in an internal web browser
      IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindow(event);
      IWorkbenchBrowserSupport browserSupport = window.getWorkbench().getBrowserSupport();

      URL webUrl;
      try {
         webUrl = new URL("http://www.qualityeclipse.com");
      }
      catch (MalformedURLException e) {
         FavoritesLog.logError(e);
         return null;
      }

      IWebBrowser browser;
      try {
         browser =
               browserSupport.createBrowser(IWorkbenchBrowserSupport.AS_EDITOR, null,
                     "Quality Eclipse", "The Quality Eclipse website");
         browser.openURL(webUrl);
      }
      catch (PartInitException e) {
         FavoritesLog.logError(e);
         return null;
      }

      return null;
   }
}
