package com.qualityeclipse.favorites.gef.editors;

import org.eclipse.gef.requests.CreationFactory;

class FavoritesCreationFactory
      implements CreationFactory
{
   private final Class<?> clazz;

   public FavoritesCreationFactory(Class<?> clazz) {
      this.clazz = clazz;
   }

   public Object getNewObject() {
      return clazz;
   }

   public Object getObjectType() {
      return clazz;
   }
}