package com.qualityeclipse.favorites.properties;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IWorkbenchPropertyPage;
import org.eclipse.ui.dialogs.PropertyPage;

import com.qualityeclipse.favorites.FavoritesLog;
import com.qualityeclipse.favorites.model.BasicFavoriteItem;

/**
 * The Favorites item properties page displayed for a resource.
 */
public class FavoriteResourcePropertyPage extends PropertyPage
      implements IWorkbenchPropertyPage
{
   private Text textField;

   /**
    * Creates and returns the SWT control for the customized body of this
    * preference page under the given parent composite. Any subclass returning a
    * <code>Composite</code> object whose <code>Layout</code> has default
    * margins (for example, a <code>GridLayout</code>) are expected to set the
    * margins of this <code>Layout</code> to 0 pixels.
    * 
    * @param parent
    *           the parent composite
    * @return the new control
    */
   protected Control createContents(Composite parent) {
      Composite panel = new Composite(parent, SWT.NONE);
      GridLayout layout = new GridLayout();
      layout.marginHeight = 0;
      layout.marginWidth = 0;
      panel.setLayout(layout);

      Label label = new Label(panel, SWT.NONE);
      label.setLayoutData(new GridData());
      label.setText("Comment that appears as hover help in the Favorites view:");

      textField = new Text(panel, SWT.BORDER | SWT.MULTI | SWT.WRAP);
      textField.setLayoutData(new GridData(GridData.FILL_BOTH));
      textField.setText(getCommentPropertyValue());

      return panel;
   }

   /**
    * Answer the favorites comment associated with the currently selected object
    * 
    * @return the favorites comment (not <code>null</code>)
    */
   protected String getCommentPropertyValue() {
      IResource resource = (IResource) getElement().getAdapter(IResource.class);
      try {
         String value = resource.getPersistentProperty(BasicFavoriteItem.COMMENT_PROPKEY);
         if (value == null)
            return BasicFavoriteItem.getDefaultComment();
         return value;
      }
      catch (CoreException e) {
         FavoritesLog.logError(e);
         return e.getMessage();
      }
   }

   /**
    * Set the favorites comment associated with the currently selected object
    * 
    * @param comment
    *           the favorites comment
    */
   protected void setCommentPropertyValue(String comment) {
      IResource resource = (IResource) getElement().getAdapter(IResource.class);
      String value = comment;
      if (value.equals(BasicFavoriteItem.getDefaultComment()))
         value = null;
      try {
         resource.setPersistentProperty(BasicFavoriteItem.COMMENT_PROPKEY, value);
      }
      catch (CoreException e) {
         FavoritesLog.logError(e);
      }
   }

   /**
    * Notifies that the OK button of this page's container has been pressed. In
    * our case, we save the favorites comment and call the superclass
    * implementation of this method.
    * 
    * @return <code>false</code> to abort the container's OK processing and
    *         <code>true</code> to allow the OK to happen
    */
   public boolean performOk() {
      setCommentPropertyValue(textField.getText());
      return super.performOk();
   }
}
