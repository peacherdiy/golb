package com.qualityeclipse.genealogy.parts;

import java.util.*;

import org.eclipse.draw2d.*;
import org.eclipse.gef.*;
import org.eclipse.gef.editpolicies.*;
import com.qualityeclipse.genealogy.figures.MarriageFigure;
import com.qualityeclipse.genealogy.model.*;
import com.qualityeclipse.genealogy.model.connection.*;
import com.qualityeclipse.genealogy.policies.NonResizableMarriageEditPolicy;

/**
 * The {@link EditPart} for the {@link Marriage} model object. This EditPart is
 * responsible for creating a visual representation for the model object and for updating
 * that visual representation as the model changes.
 */
public class MarriageEditPart extends GenealogyElementEditPart
{
	public MarriageEditPart(Marriage marriage) {
		setModel(marriage);
	}

	public Marriage getModel() {
		return (Marriage) super.getModel();
	}

	/**
	 * Create and return the figure representing this model object
	 */
	protected IFigure createFigure() {
		return new MarriageFigure(getModel().getYearMarried());
	}
	
	/**
	 * Answer a collection of connection model objects that originate from the receiver.
	 */
	protected List<GenealogyConnection> getModelSourceConnections() {
		Marriage model = getModel();
		ArrayList<GenealogyConnection> offspringList = new ArrayList<GenealogyConnection>();
		for (Person offspring : model.getOffspring())
			offspringList.add(new GenealogyConnection(offspring, model));
		return offspringList;
	}

	/**
	 * Answer a collection of connection model objects that terminate at the receiver.
	 */
	protected List<GenealogyConnection> getModelTargetConnections() {
		Marriage marriage = getModel();
		ArrayList<GenealogyConnection> marriageList = new ArrayList<GenealogyConnection>(1);
		Person husband = marriage.getHusband();
		if (husband != null)
			marriageList.add(new GenealogyConnection(husband, marriage));
		Person wife = marriage.getWife();
		if (wife != null)
			marriageList.add(new GenealogyConnection(wife, marriage));
		return marriageList;
	}

	/**
	 * Extend the superclass behavior to modify the associated figure's appearance to show
	 * that the element is selected.
	 */
	protected void fireSelectionChanged() {
		((MarriageFigure) getFigure()).setSelected(getSelected() != 0);
		super.fireSelectionChanged();
	}

	/**
	 * Create and install {@link EditPolicy} instances used to define behavior
	 * associated with this EditPart's figure.
	 */
	protected void createEditPolicies() {
		NonResizableEditPolicy selectionPolicy = new NonResizableMarriageEditPolicy();
		selectionPolicy.setDragAllowed(false);
		installEditPolicy(EditPolicy.SELECTION_FEEDBACK_ROLE, selectionPolicy);
	}
}
