package com.qualityeclipse.favorites.model.type;

import org.eclipse.core.resources.IProject;

import com.qualityeclipse.favorites.model.FavoriteItemFactory;
import com.qualityeclipse.favorites.model.FavoriteItemType;
import com.qualityeclipse.favorites.model.FavoriteResource;
import com.qualityeclipse.favorites.model.IFavoriteItem;

public class ProjectFactory extends FavoriteItemFactory
{
   public IFavoriteItem newFavorite(FavoriteItemType type, Object obj) {
      if (!(obj instanceof IProject))
         return null;
      return new FavoriteResource(type, (IProject) obj);
   }

   public IFavoriteItem loadFavorite(FavoriteItemType type, String info) {
      return FavoriteResource.loadFavorite(type, info);
   }
}
