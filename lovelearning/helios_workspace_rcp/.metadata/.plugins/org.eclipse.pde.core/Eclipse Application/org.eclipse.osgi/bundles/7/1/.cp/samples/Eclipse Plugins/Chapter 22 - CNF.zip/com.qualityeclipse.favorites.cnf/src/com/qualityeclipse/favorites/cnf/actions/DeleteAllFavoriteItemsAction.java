package com.qualityeclipse.favorites.cnf.actions;

import org.eclipse.jface.action.IAction;
import org.eclipse.ui.actions.ActionDelegate;

import com.qualityeclipse.favorites.model.FavoritesManager;

@SuppressWarnings("restriction")
public class DeleteAllFavoriteItemsAction extends ActionDelegate {
	
	@Override
	public void run(IAction action) {
		FavoritesManager manager = FavoritesManager.getManager();
		manager.removeFavorites(manager.getFavorites());
		super.run(action);
	}
	
}
