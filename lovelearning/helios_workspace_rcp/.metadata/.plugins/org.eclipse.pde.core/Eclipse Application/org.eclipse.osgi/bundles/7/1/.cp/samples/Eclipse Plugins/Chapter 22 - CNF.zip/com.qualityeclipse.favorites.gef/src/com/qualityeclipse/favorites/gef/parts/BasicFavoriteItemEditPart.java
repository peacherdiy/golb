package com.qualityeclipse.favorites.gef.parts;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.draw2d.FlowLayout;
import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.Label;
import org.eclipse.draw2d.PositionConstants;
import org.eclipse.draw2d.RoundedRectangle;
import org.eclipse.draw2d.geometry.Insets;
import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.gef.EditPolicy;

import com.qualityeclipse.favorites.gef.model.FavoritesConnection;
import com.qualityeclipse.favorites.gef.policies.FavoriteItemComponentEditPolicy;
import com.qualityeclipse.favorites.model.BasicFavoriteItem;

/**
 * Base class for behavior shared by {@link FavoriteResourceEditPart} and
 * {@link FavoriteJavaElementEditPart}.
 */
public class BasicFavoriteItemEditPart extends AbstractFavoritesNodeEditPart
{
   private static final Insets CLIENT_AREA_INSETS = new Insets(10, 10, 21, 21);

   private final Label label = new Label();

   private final List<FavoritesConnection> modelSourceConnections;

   public BasicFavoriteItemEditPart(BasicFavoriteItem item) {
      setModel(item);
      label.setText(item.getName());
      label.setIcon(item.getType().getImage());
      IResource res = (IResource) item.getAdapter(IResource.class);
      modelSourceConnections = new ArrayList<FavoritesConnection>(1);
      modelSourceConnections.add(new FavoritesConnection(item, res));
   }

   public BasicFavoriteItem getBasicFavoriteItem() {
      return (BasicFavoriteItem) getModel();
   }

   protected List<FavoritesConnection> getModelSourceConnections() {
      return modelSourceConnections;
   }

   protected IFigure createFigure() {
      RoundedRectangle figure = new RoundedRectangle() {
         public Rectangle getClientArea(Rectangle rect) {
            Rectangle clientArea = super.getClientArea(rect);
            clientArea.crop(CLIENT_AREA_INSETS);
            return clientArea;
         }
      };
      figure.setSize(150, 40);
      FlowLayout layout = new FlowLayout();
      layout.setMajorAlignment(FlowLayout.ALIGN_CENTER);
      layout.setMinorAlignment(FlowLayout.ALIGN_CENTER);
      figure.setLayoutManager(layout);
      label.setTextAlignment(PositionConstants.LEFT);
      figure.add(label);
      figure.setToolTip(createToolTipLabel());
      return figure;
   }

   public String getSortKey() {
      BasicFavoriteItem elem = getBasicFavoriteItem();
      IResource res = (IResource) elem.getAdapter(IResource.class);
      return res.getName() + "," + elem.getName() + "," + elem.getType().getId();
   }

   protected void createEditPolicies() {
      installEditPolicy(EditPolicy.COMPONENT_ROLE, new FavoriteItemComponentEditPolicy());
   }
}
