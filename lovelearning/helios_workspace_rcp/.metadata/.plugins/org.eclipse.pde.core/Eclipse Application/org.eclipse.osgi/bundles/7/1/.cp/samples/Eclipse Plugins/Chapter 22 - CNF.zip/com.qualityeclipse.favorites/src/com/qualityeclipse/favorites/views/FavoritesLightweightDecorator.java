package com.qualityeclipse.favorites.views;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.IDecoration;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.ILightweightLabelDecorator;
import org.eclipse.jface.viewers.LabelProviderChangedEvent;

import com.qualityeclipse.favorites.FavoritesActivator;
import com.qualityeclipse.favorites.model.FavoritesManager;
import com.qualityeclipse.favorites.model.FavoritesManagerEvent;
import com.qualityeclipse.favorites.model.FavoritesManagerListener;
import com.qualityeclipse.favorites.model.IFavoriteItem;

/**
 * A decorator to decorate objects in other views that also appear in
 * the Favorites view.
 */
public class FavoritesLightweightDecorator
      implements ILightweightLabelDecorator, FavoritesManagerListener
{
   private static final String SUFFIX = " [favorite]";
   private static final ImageDescriptor OVERLAY =
         FavoritesActivator.imageDescriptorFromPlugin(FavoritesActivator.PLUGIN_ID,
               "icons/favorites_overlay.gif");

   private final FavoritesManager manager = FavoritesManager.getManager();
   private final List<ILabelProviderListener> listenerList =
         new ArrayList<ILabelProviderListener>();

   public FavoritesLightweightDecorator() {
      // Make sure that the Favorites are loaded.
      manager.getFavorites();
      manager.addFavoritesManagerListener(this);
   }

   /**
    * Cleanup the receiver by removing the receiver from the
    * FavoritesManager so that the receiver does not receive any more
    * change events.
    */
   public void dispose() {
      manager.removeFavoritesManagerListener(this);
   }

   /**
    * Adds an overlay icon and appends text if the specified elements
    * is also in the favorites view.
    * 
    * @param element the element to decorate
    * @param decoration the decoration to set
    * @see ILightweightLabelDecorator#decorate(Object, IDecoration)
    */
   public void decorate(Object element, IDecoration decoration) {
      if (manager.existingFavoriteFor(element) != null) {
         decoration.addOverlay(OVERLAY);
         decoration.addSuffix(SUFFIX);
      }
   }

   /**
    * Adds a listener to this label provider. Has no effect if an
    * identical listener is already registered.
    * <p>
    * Label provider listeners are informed about state changes that
    * affect the rendering of the viewer that uses this label
    * provider.
    * </p>
    * 
    * @param listener a label provider listener
    * @see org.eclipse.jface.viewers.IBaseLabelProvider#addListener(org.eclipse.jface.viewers.ILabelProviderListener)
    */
   public void addListener(ILabelProviderListener listener) {
      if (!listenerList.contains(listener))
         listenerList.add(listener);
   }

   /**
    * Removes a listener to this label provider. Has no affect if an
    * identical listener is not registered.
    * 
    * @param listener a label provider listener
    * @see org.eclipse.jface.viewers.IBaseLabelProvider#removeListener(org.eclipse.jface.viewers.ILabelProviderListener)
    */
   public void removeListener(ILabelProviderListener listener) {
      listenerList.remove(listener);
   }

   /**
    * Called when the FavoritesManager has added and/or removed
    * elements so that the reciever can notify others of the change
    * 
    * @param favoritesEvent the event describing the elements added
    *           and removed
    * @see com.qualityeclipse.favorites.model.FavoritesManagerListener#favoritesChanged(com.qualityeclipse.favorites.model.FavoritesManagerEvent)
    */
   public void favoritesChanged(FavoritesManagerEvent event) {
      Collection<Object> elements = new HashSet<Object>();
      addResourcesTo(event.getItemsAdded(), elements);
      addResourcesTo(event.getItemsRemoved(), elements);

      LabelProviderChangedEvent labelEvent =
            new LabelProviderChangedEvent(this, elements.toArray());

      Iterator<ILabelProviderListener> iter = listenerList.iterator();
      while (iter.hasNext())
         iter.next().labelProviderChanged(labelEvent);
   }

   /**
    * Append resources represented by the specified favorite items to
    * the specified collection
    * 
    * @param items the favorite items representing resources
    * @param elements a collection of resources
    */
   private void addResourcesTo(IFavoriteItem[] items, Collection<Object> elements) {
      for (int i = 0; i < items.length; i++) {
         IFavoriteItem item = items[i];
         Object res = item.getAdapter(IResource.class);
         if (res != null)
            elements.add(res);
      }
   }

   /**
    * Returns whether the label would be affected by a change to the
    * given property of the given element. This can be used to
    * optimize a non-structural viewer update. If the property
    * mentioned in the update does not affect the label, then the
    * viewer need not update the label.
    * 
    * @param element the element
    * @param property the property
    * @return <code>true</code> if the label would be affected, and
    *         <code>false</code> if it would be unaffected
    * @see org.eclipse.jface.viewers.IBaseLabelProvider#isLabelProperty(java.lang.Object,
    *      java.lang.String)
    */
   public boolean isLabelProperty(Object element, String property) {
      return false;
   }
}
