package com.qualityeclipse.favorites.model;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.views.properties.ColorPropertyDescriptor;
import org.eclipse.ui.views.properties.IPropertyDescriptor;
import org.eclipse.ui.views.properties.IPropertySheetEntry;
import org.eclipse.ui.views.properties.IPropertySource;
import org.eclipse.ui.views.properties.IPropertySource2;
import org.eclipse.ui.views.properties.TextPropertyDescriptor;

import com.qualityeclipse.favorites.FavoritesActivator;

/**
 * Common superclass for sharing behavior among implementors of
 * {@link com.qualityeclipse.favorites.model.IFavoriteItem}.
 */
public abstract class BasicFavoriteItem
      implements IFavoriteItem, IPropertySource2
{
   // //////////////////////////////////////////////////////////////////////////
   //
   // Individual item properties and accessors
   //
   // //////////////////////////////////////////////////////////////////////////

   /**
    * Key used to access the persistent resource property as in: <code>
    *    String comment = resource.getPersistentProperty(BasicFavoriteItem.COMMENT_PROPKEY);
    * </code> and
    * <code>
    *    resource.setPersistentProperty(BasicFavoriteItem.COMMENT_PROPKEY,comment);
    * </code>
    */
   public static final QualifiedName COMMENT_PROPKEY =
         new QualifiedName(FavoritesActivator.PLUGIN_ID, "comment");

   private Color color;

   /**
    * Answer the color for this item
    */
   public Color getColor() {
      if (color == null)
         return getDefaultColor();
      return color;
   }

   /**
    * Set the color for this item
    */
   public void setColor(Color color) {
      this.color = color;
      FavoritesManager.getManager().fireFavoritesItemChanged(this);
   }

   // //////////////////////////////////////////////////////////////////////////
   //
   // Shared static properties and utilities
   //
   // //////////////////////////////////////////////////////////////////////////

   private static final String COMMENT_PREFKEY = "defaultComment";
   private static final Map<RGB, Color> colorCache = new HashMap<RGB, Color>();
   private static Color defaultColor;

   /**
    * Answer the default color for all favorite items
    */
   public static Color getDefaultColor() {
      if (defaultColor == null)
         defaultColor = getColor(new RGB(0, 0, 0));
      return defaultColor;
   }

   /**
    * Set the default color for all favorite items
    */
   public static void setDefaultColor(Color color) {
      defaultColor = color;
   }

   /**
    * Answer an OS object for the specified RGB value
    * 
    * @param rgb
    *           the color's RGB value
    * @return the corresponding OS color object
    */
   public static Color getColor(RGB rgb) {
      Color color = colorCache.get(rgb);
      if (color == null) {
         Display display = Display.getCurrent();
         color = new Color(display, rgb);
         colorCache.put(rgb, color);
      }
      return color;
   }

   /**
    * Dispose of all cached colors. This should be called when the plug-in shuts
    * down.
    */
   public static void disposeColors() {
      Iterator<Color> iter = colorCache.values().iterator();
      while (iter.hasNext())
         iter.next().dispose();
      colorCache.clear();
   }

   /**
    * Answer the default comment for all items
    * 
    * @return the comment (not <code>null</code>)
    */
   public static String getDefaultComment() {
      return FavoritesActivator.getDefault().getPreferenceStore().getString(
            COMMENT_PREFKEY);
   }

   /**
    * Set the default comment for all items
    * 
    * @param comment
    *           the comment (not <code>null</code>)
    */
   public static void setDefaultComment(String comment) {
      FavoritesActivator.getDefault().getPreferenceStore().setValue(COMMENT_PREFKEY,
            comment);
   }

   // //////////////////////////////////////////////////////////////////////////
   //
   // Property View related fields and accessors
   //
   // //////////////////////////////////////////////////////////////////////////

   private static final String COLOR_ID = "favorite.color";
   private static final ColorPropertyDescriptor COLOR_PROPERTY_DESCRIPTOR =
         new ColorPropertyDescriptor(COLOR_ID, "Color");

   private static final String HASH_ID = "favorite.hash";
   private static final TextPropertyDescriptor HASH_PROPERTY_DESCRIPTOR =
         new TextPropertyDescriptor(HASH_ID, "Hash Code");
   static {
      HASH_PROPERTY_DESCRIPTOR.setCategory("Other");
      HASH_PROPERTY_DESCRIPTOR.setFilterFlags(new String[] { IPropertySheetEntry.FILTER_ID_EXPERT });
      HASH_PROPERTY_DESCRIPTOR.setAlwaysIncompatible(true);
   }

   private static final IPropertyDescriptor[] DESCRIPTORS = {
         COLOR_PROPERTY_DESCRIPTOR, HASH_PROPERTY_DESCRIPTOR };

   /**
    * Returns a value for this property source that can be edited in a property
    * sheet.
    */
   public Object getEditableValue() {
      return this;
   }

   /**
    * Returns the list of property descriptors for this property source. The
    * <code>getPropertyValue</code> and <code>setPropertyValue</code> methods
    * are used to read and write the actual property values by specifying the
    * property ids from these property descriptors.
    */
   public IPropertyDescriptor[] getPropertyDescriptors() {
      return DESCRIPTORS;
   }

   /**
    * Returns the value of the property with the given id if it has one. Returns
    * <code>null</code> if the property's value is <code>null</code> value or if
    * this source does not have the specified property.
    * 
    * @see #setPropertyValue
    * @param id
    *           the id of the property being set
    * @return the value of the property, or <code>null</code>
    */
   public Object getPropertyValue(Object id) {
      if (COLOR_ID.equals(id))
         return getColor().getRGB();
      if (HASH_ID.equals(id))
         return new Integer(hashCode());
      return null;
   }

   /**
    * Returns whether the value of the property with the given id has changed
    * from its default value. Returns <code>false</code> if this source does not
    * have the specified property.
    * 
    * @param id
    *           the id of the property
    * @return <code>true</code> if the value of the specified property has
    *         changed from its original default value, <code>true</code> if the
    *         specified property does not have a meaningful default value, and
    *         <code>false</code> if this source does not have the specified
    *         property
    * @see IPropertySource2#isPropertyResettable(Object)
    * @see #resetPropertyValue(Object)
    */
   public boolean isPropertySet(Object id) {
      if (COLOR_ID.equals(id))
         return getColor() != getDefaultColor();
      if (HASH_ID.equals(id)) {
         // return true for indicating that hash
         // does not have a meaningful default value
         return true;
      }
      return false;
   }

   /**
    * Returns whether the value of the property with the specified id is
    * resettable to a default value.
    * 
    * @param id
    *           the id of the property
    * @return <code>true</code> if the property with the specified id has a
    *         meaningful default value to which it can be resetted, and
    *         <code>false</code> otherwise
    * @see IPropertySource#resetPropertyValue(Object)
    * @see IPropertySource#isPropertySet(Object)
    */
   public boolean isPropertyResettable(Object id) {
      if (COLOR_ID.equals(id))
         return true;
      return false;
   }

   /**
    * Resets the property with the given id to its default value if possible.
    * Does nothing if the notion of a default value is not meaningful for the
    * specified property, or if the property's value cannot be changed, or if
    * this source does not have the specified property.
    * 
    * Callers will check if this <code>IPropertySource</code> implements
    * <code>IPropertySource2</code> and this method will only be called if
    * <code>IPropertySource2#isPropertyResettable(Object)</code> returns
    * <code>true</code> for the property with the given id. </p>
    * 
    * @param id
    *           the id of the property being reset
    * @see #isPropertySet(Object)
    * @see IPropertySource2#isPropertyResettable(Object)
    */
   public void resetPropertyValue(Object id) {
      if (COLOR_ID.equals(id))
         setColor(null);
   }

   /**
    * Sets the property with the given id if possible. Does nothing if the
    * property's value cannot be changed or if this source does not have the
    * specified property.
    * 
    * @see #getPropertyValue
    * @see #getEditableValue
    * @param id
    *           the id of the property being set
    * @param value
    *           the new value for the property; <code>null</code> is allowed
    */
   public void setPropertyValue(Object id, Object value) {
      if (COLOR_ID.equals(id))
         setColor(getColor((RGB) value));
   }
}