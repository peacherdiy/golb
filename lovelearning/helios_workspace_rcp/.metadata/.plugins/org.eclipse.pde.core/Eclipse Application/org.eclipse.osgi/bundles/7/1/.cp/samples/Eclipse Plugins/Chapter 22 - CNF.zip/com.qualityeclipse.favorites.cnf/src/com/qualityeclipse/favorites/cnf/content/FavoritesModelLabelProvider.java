package com.qualityeclipse.favorites.cnf.content;

import org.eclipse.core.resources.IFile;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;

import com.qualityeclipse.favorites.cnf.FavoritesCNFActivator;
import com.qualityeclipse.favorites.model.FavoritesManager;
import com.qualityeclipse.favorites.model.IFavoriteItem;

@SuppressWarnings("restriction")
public class FavoritesModelLabelProvider extends LabelProvider implements
		ILabelProvider {
	
	@Override
	public Image getImage(Object element) {
		if(element instanceof FavoritesManager) {
			Image image = FavoritesCNFActivator.getImageDescriptor("icons/sample.gif").createImage();
	        return image;
		} else if(element instanceof IFavoriteItem) {
			Image image = ((IFavoriteItem) element).getType().getImage();
	        return image;
		}
		return super.getImage(element);
	}
	
	@Override
	public String getText(Object element) {
		if(element instanceof FavoritesManager) {
			return "Favorites";
		} else if(element instanceof IFavoriteItem) {
			return ((IFavoriteItem) element).getName();
		} else if(element instanceof IFile) {
			return ((IFile) element).getName();
		}
		return super.getText(element);
	}
	
}
