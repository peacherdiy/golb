package com.qualityeclipse.favorites.cnf.filters;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;

import com.qualityeclipse.favorites.model.FavoritesManager;
import com.qualityeclipse.favorites.model.IFavoriteItem;

@SuppressWarnings("restriction")
public class FavoritesViewerFilter extends ViewerFilter {

	private final FavoritesManager favoritesManager = FavoritesManager.getManager();
	
	@Override
	public boolean select(Viewer viewer, Object parentElement, Object element) {
		IFavoriteItem[] favoriteItems = favoritesManager.getFavorites();
		for (int i = 0; i < favoriteItems.length; i++) {
			if(favoriteItems[i].isFavoriteFor(element)) {
				return true;
			} else if (element instanceof ICompilationUnit &&
					favoriteItems[i].isFavoriteFor(((ICompilationUnit) element).getResource())) {
				return true;
			}
			if(element instanceof IContainer) {
				IContainer container = (IContainer) element;
				if(isInContainer(container, favoriteItems[i].getName())) {
					return true;
				}
			} else if(element instanceof IJavaElement) {
				IJavaElement javaElement = (IJavaElement) element;
				IResource resource = javaElement.getResource();
				if(resource != null && resource instanceof IContainer) {
					IContainer container = (IContainer) resource;
					if(isInContainer(container, favoriteItems[i].getName())) {
						return true;
					}
				}
			}
		}
		return false;
	}
	
	private boolean isInContainer(IContainer container, String resourceName) {
		if(container.findMember(resourceName) != null) {
			return true;
		}
		IResource[] children = null;
		try {
			children = container.members();
		} catch (CoreException e) {
		}
		for (int i = 0; i < children.length; i++) {
			if(children[i] instanceof IContainer) {
				if(isInContainer((IContainer)children[i], resourceName)) {
					return true;
				}
			}
		}
		return false;
	}

}
