package com.qualityeclipse.favorites.views;

import org.eclipse.osgi.util.NLS;

public class Messages extends NLS
{
   private static final String BUNDLE_NAME =
         "com.qualityeclipse.favorites.views.messages"; //$NON-NLS-1$
   public static String FavoritesView_LocationColumnLabel;
   public static String FavoritesView_NameColumnLabel;
   public static String FavoritesView_OpenFilterCommandLabel;
   public static String FavoritesView_TypeColumnLabel;
   static {
      // initialize resource bundle
      NLS.initializeMessages(BUNDLE_NAME, Messages.class);
   }

   private Messages() {
   }
}
