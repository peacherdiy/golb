package com.qualityeclipse.favorites.gef.parts;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.IResource;
import org.eclipse.draw2d.IFigure;

import com.qualityeclipse.favorites.gef.figures.ResourceFigure;
import com.qualityeclipse.favorites.gef.model.FavoritesConnection;

/**
 * The edit part corresponding to the {@link IResource} Eclipse model object.
 */
public class ResourceEditPart extends AbstractFavoritesNodeEditPart
{
   private final ResourceFigure resourceFigure = new ResourceFigure();
   private final List<FavoritesConnection> modelTargetConnections = new ArrayList<FavoritesConnection>();
   
   public ResourceEditPart(IResource resource) {
      setModel(resource);
      resourceFigure.setText(resource.getName());
   }

   public IResource getResource() {
      return (IResource) getModel();
   }

   protected List<FavoritesConnection> getModelTargetConnections() {
      return modelTargetConnections;
   }

   /**
    * Add the specified target connection
    * 
    * @param editPart
    *           the connection to be added
    * @return <code>true</code> if the connection was added, else
    *         <code>false</code>
    * @see com.qualityeclipse.favorites.gef.parts.AbstractFavoritesNodeEditPart#addTargetConnection(com.qualityeclipse.favorites.gef.parts.FavoriteConnectionEditPart)
    */
   public boolean addFavoritesTargetConnection(FavoriteConnectionEditPart editPart) {
      FavoritesConnection conn = editPart.getFavoritesConnection();
      if (!conn.getResource().equals(getResource()))
         return false;
      modelTargetConnections.add(conn);
      addTargetConnection(editPart, 0);
      return true;
   }

   public boolean removeFavoritesTargetConnection(FavoriteConnectionEditPart conn) {
      if (!modelTargetConnections.remove(conn.getModel()))
         return false;
      removeTargetConnection(conn);
      return true;
   }

   protected IFigure createFigure() {
      resourceFigure.setSize(150, 40);
      resourceFigure.setToolTip(createToolTipLabel());
      return resourceFigure;
   }
   
   public String getSortKey() {
      return getResource().getName();
   }

   protected void createEditPolicies() {
      // ??? see section ???
   }
}
