package com.qualityeclipse.favorites.model.type;

import org.eclipse.jdt.core.IClassFile;

import com.qualityeclipse.favorites.model.FavoriteItemFactory;
import com.qualityeclipse.favorites.model.FavoriteItemType;
import com.qualityeclipse.favorites.model.FavoriteJavaElement;
import com.qualityeclipse.favorites.model.IFavoriteItem;

public class JavaClassFileFactory extends FavoriteItemFactory
{
   public IFavoriteItem newFavorite(FavoriteItemType type, Object obj) {
      if (!(obj instanceof IClassFile))
         return null;
      return new FavoriteJavaElement(type, (IClassFile) obj);
   }

   public IFavoriteItem loadFavorite(FavoriteItemType type, String info) {
      return FavoriteJavaElement.loadFavorite(type, info);
   }
}
