package com.qualityeclipse.favorites.gef.layouts;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;

import org.eclipse.draw2d.AbstractLayout;
import org.eclipse.draw2d.IFigure;
import org.eclipse.draw2d.geometry.Dimension;
import org.eclipse.draw2d.geometry.Point;
import org.eclipse.draw2d.geometry.Rectangle;

import com.qualityeclipse.favorites.gef.figures.ResourceFigure;

/**
 * Layout for placing {@link ResourceFigure}s in one column and all other
 * figures, representing favorite items, in another.
 */
public class FavoritesLayout extends AbstractLayout
{
   private final Map<IFigure, String> constraints = new HashMap<IFigure, String>(20);

   public Object getConstraint(IFigure child) {
      return constraints.get(child);
   }
   
   /**
    * Extend the superclass implementation to cache the constraint, which must
    * be a string.
    * 
    * @see org.eclipse.draw2d.AbstractLayout#setConstraint(org.eclipse.draw2d.IFigure,
    *      java.lang.Object)
    */
   public void setConstraint(IFigure child, Object constraint) {
      super.setConstraint(child, constraint);
      if (constraint instanceof String)
         constraints.put(child, (String) constraint);
   }

   /**
    * Extend the superclass implementation to remove the child from the
    * constraint map.
    * 
    * @see org.eclipse.draw2d.AbstractLayout#remove(org.eclipse.draw2d.IFigure)
    */
   public void remove(IFigure child) {
      super.remove(child);
      constraints.remove(child);
   }

   /**
    * Don't bother calculating the preferred size because we set the parent's
    * bounds in the {@link #layout(IFigure)} method.
    * 
    * @see org.eclipse.draw2d.AbstractLayout#calculatePreferredSize(org.eclipse.draw2d.IFigure,
    *      int, int)
    */
   protected Dimension calculatePreferredSize(IFigure container, int hint, int hint2) {
      return null;
   }

   /**
    * Layout the child figures based upon the constraints and set the bounds of
    * the parent to contain those children.
    * 
    * @see org.eclipse.draw2d.LayoutManager#layout(org.eclipse.draw2d.IFigure)
    */
   public void layout(IFigure parent) {
      TreeMap<String, IFigure> children = new TreeMap<String, IFigure>();
      for (Iterator<Entry<IFigure, String>> iter = constraints.entrySet().iterator(); iter.hasNext();) {
         Entry<IFigure, String> entry = iter.next();
         children.put(entry.getValue(), entry.getKey());
      }
      int y = 5;
      int w = 0;
      for (Iterator<Entry<String, IFigure>> iter = children.entrySet().iterator(); iter.hasNext();) {
         Entry<String, IFigure> entry = iter.next();
         IFigure figure = entry.getValue();
         Point offset;
         Dimension size = figure.getSize();
         if (figure instanceof ResourceFigure) {
            offset = new Point(5, y);
         }
         else {
            offset = new Point(200, y);
            y += size.height + 5;
         }
         w = Math.max(w, offset.x + size.width);
         figure.setBounds(new Rectangle(offset, size));
      }
      parent.setBounds(new Rectangle(0, 0, w + 5, y));
   }
}
