package com.qualityeclipse.favorites.cnf.content;

import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.Viewer;

import com.qualityeclipse.favorites.model.FavoriteJavaElement;
import com.qualityeclipse.favorites.model.FavoriteResource;
import com.qualityeclipse.favorites.model.FavoritesManager;

@SuppressWarnings("restriction")
public class FavoritesModelContentProvider implements ITreeContentProvider {

	private FavoritesManager model;
	
	@Override
	public Object[] getChildren(Object parentElement) {
		if(parentElement instanceof FavoritesManager) {
			return model.getFavorites();
		}  else if(parentElement instanceof FavoriteJavaElement) {
			return new Object[]{((FavoriteJavaElement) parentElement).getAdapter(org.eclipse.jdt.core.IJavaElement.class)};
		} else if(parentElement instanceof FavoriteResource) {
			return new Object[]{((FavoriteResource) parentElement).getAdapter(org.eclipse.core.resources.IResource.class)};
		}
		return new Object[]{};
	}

	@Override
	public Object getParent(Object element) {
		return null;
	}

	@Override
	public boolean hasChildren(Object element) {
		return getChildren(element).length > 0;
	}

	@Override
	public Object[] getElements(Object inputElement) {
		if(inputElement instanceof IWorkspaceRoot) {
			return new Object[]{model};
		} else {
			return new Object[]{};
		}
	}

	@Override
	public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
		model = FavoritesManager.getManager();
	}
	
	@Override
	public void dispose() {
		model = null;
	}

}
