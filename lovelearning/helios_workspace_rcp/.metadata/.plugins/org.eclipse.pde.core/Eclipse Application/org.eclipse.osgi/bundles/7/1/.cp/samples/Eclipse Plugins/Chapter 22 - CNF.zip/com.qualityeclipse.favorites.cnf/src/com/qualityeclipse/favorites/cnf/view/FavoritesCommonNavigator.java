package com.qualityeclipse.favorites.cnf.view;

import org.eclipse.ui.navigator.CommonNavigator;

import com.qualityeclipse.favorites.model.FavoritesManager;
import com.qualityeclipse.favorites.model.FavoritesManagerEvent;
import com.qualityeclipse.favorites.model.FavoritesManagerListener;

@SuppressWarnings("restriction")
public class FavoritesCommonNavigator extends CommonNavigator implements FavoritesManagerListener {

	FavoritesManager manager = FavoritesManager.getManager();
	
	public FavoritesCommonNavigator() {
		manager.addFavoritesManagerListener(this);
	}

	@Override
	public void favoritesChanged(FavoritesManagerEvent event) {
		getCommonViewer().refresh();
	}
	
}
