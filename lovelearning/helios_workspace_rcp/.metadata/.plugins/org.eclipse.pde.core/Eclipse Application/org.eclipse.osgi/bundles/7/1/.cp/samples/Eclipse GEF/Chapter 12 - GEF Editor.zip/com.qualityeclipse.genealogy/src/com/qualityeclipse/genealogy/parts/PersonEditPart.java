package com.qualityeclipse.genealogy.parts;

import java.util.*;

import org.eclipse.draw2d.IFigure;
import org.eclipse.gef.*;
import org.eclipse.gef.editpolicies.NonResizableEditPolicy;
import org.eclipse.swt.graphics.Image;

import com.qualityeclipse.genealogy.figures.PersonFigure;
import com.qualityeclipse.genealogy.model.*;
import com.qualityeclipse.genealogy.model.connection.*;

/**
 * The {@link EditPart} for the {@link Person} model object. This EditPart is responsible
 * for creating a visual representation for the model object and for updating that visual
 * representation as the model changes.
 */
public class PersonEditPart extends GenealogyElementEditPart
{
	public PersonEditPart(Person person) {
		setModel(person);
	}

	public Person getModel() {
		return (Person) super.getModel();
	}

	/**
	 * Create and return the figure representing this model object
	 */
	protected IFigure createFigure() {
		Person m = getModel();
		Image image = m.getGender() == Person.Gender.MALE ? PersonFigure.MALE : PersonFigure.FEMALE;
		return new PersonFigure(m.getName(), image, m.getBirthYear(), m.getDeathYear());
	}

	/**
	 * Override the superclass implementation to return a special figure nested within
	 * {@link PersonFigure} that only contains notes.
	 */
	public IFigure getContentPane() {
		return ((PersonFigure) getFigure()).getNotesContainer();
	}

	/**
	 * Answer the embedded notes to be displayed
	 */
	protected List<Note> getModelChildren() {
		return getModel().getNotes();
	}

	/**
	 * Answer a collection of connection model objects that originate with the receiver.
	 */
	public List<GenealogyConnection> getModelSourceConnections() {
		Person person = getModel();
		Marriage marriage = person.getMarriage();
		ArrayList<GenealogyConnection> marriageList = new ArrayList<GenealogyConnection>(1);
		if (marriage != null)
			marriageList.add(new GenealogyConnection(person, marriage));
		return marriageList;
	}

	/**
	 * Answer a collection of connection model objects that terminate at the receiver.
	 */
	protected List<GenealogyConnection> getModelTargetConnections() {
		ArrayList<GenealogyConnection> offspringList = new ArrayList<GenealogyConnection>();
		Person person = getModel();
		Marriage parentsMarriage = person.getParentsMarriage();
		if (parentsMarriage != null)
			offspringList.add(new GenealogyConnection(person, parentsMarriage));
		return offspringList;
	}

	/**
	 * Extend the superclass behavior to modify the associated figure's appearance to show
	 * that the element is selected.
	 */
	protected void fireSelectionChanged() {
		((PersonFigure) getFigure()).setSelected(getSelected() != 0);
		super.fireSelectionChanged();
	}

	/**
	 * Create and install {@link EditPolicy} instances used to define behavior
	 * associated with this EditPart's figure.
	 */
	protected void createEditPolicies() {
		NonResizableEditPolicy selectionPolicy = new NonResizableEditPolicy();
		selectionPolicy.setDragAllowed(false);
		installEditPolicy(EditPolicy.SELECTION_FEEDBACK_ROLE, selectionPolicy);
	}
}
