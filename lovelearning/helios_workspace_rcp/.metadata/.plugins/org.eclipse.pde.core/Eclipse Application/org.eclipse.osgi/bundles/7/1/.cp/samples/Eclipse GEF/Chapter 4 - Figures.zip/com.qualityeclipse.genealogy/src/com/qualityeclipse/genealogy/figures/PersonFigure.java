package com.qualityeclipse.genealogy.figures;

import org.eclipse.draw2d.*;
import org.eclipse.draw2d.geometry.*;
import org.eclipse.swt.graphics.Pattern;
import org.eclipse.swt.widgets.Display;

import com.qualityeclipse.genealogy.listener.FigureMover;

/**
 * A custom figure for the GenealogyView displaying a person's information
 */
public class PersonFigure extends Figure {

	public PersonFigure(String name, int birthYear, int deathYear) {
		final ToolbarLayout layout = new ToolbarLayout();
		layout.setSpacing(1);
		setLayoutManager(layout);
		setPreferredSize(100, 100);
		setBorder(new CompoundBorder(
			new LineBorder(1),
			new MarginBorder(2, 2, 2, 2)));
		
		// Display the name as a nested figure
		add(new Label(name));

		// Display the year of birth and death
		String datesText = birthYear + " -";
		if (deathYear != -1)
			datesText += " " + deathYear;
		add(new Label(datesText)); 
		
		new FigureMover(this);
	}

	public void paintFigure(Graphics graphics) {
		Rectangle r = getBounds();
		graphics.setBackgroundPattern(new Pattern(Display.getCurrent(), r.x,
				r.y, r.x + r.width, r.y + r.height, ColorConstants.white,
				ColorConstants.lightGray));
		graphics.fillRectangle(r);
	}
}
