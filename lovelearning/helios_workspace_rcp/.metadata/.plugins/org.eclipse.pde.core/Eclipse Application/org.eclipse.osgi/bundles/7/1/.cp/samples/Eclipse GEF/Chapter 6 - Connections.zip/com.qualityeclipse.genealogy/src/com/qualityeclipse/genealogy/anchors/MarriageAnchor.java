package com.qualityeclipse.genealogy.anchors;

import org.eclipse.draw2d.*;
import org.eclipse.draw2d.geometry.*;

import static com.qualityeclipse.genealogy.figures.MarriageFigure.RADIUS;

/**
 * An anchor for the center of the {@link MarriageFigure} that returns a
 * location along the outside edge of the {@link MarriageFigure}
 */
public class MarriageAnchor extends AbstractConnectionAnchor {
	public MarriageAnchor(IFigure owner) {
		super(owner);
	}

	public Point getLocation(Point reference) {
		Point origin = getOwner().getBounds().getCenter();

		int Ax = Math.abs(reference.x - origin.x);
		int Ay = Math.abs(reference.y - origin.y);

		int divisor = Ax + Ay;
		if (divisor == 0)
			return origin;

		int x = (RADIUS * Ax) / divisor;
		int y = (RADIUS * Ay) / divisor;

		if (reference.x < origin.x)
			x = -x;
		if (reference.y < origin.y)
			y = -y;

		return new Point(origin.x + x, origin.y + y);
	}
}