package com.qualityeclipse.favorites.handlers;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.ui.PlatformUI;

/**
 * Show help for the Favorites view
 */
public class OpenFavoritesViewHelp extends AbstractHandler
{
   public Object execute(ExecutionEvent event) throws ExecutionException {

      // Show the help window
      // PlatformUI.getWorkbench().getHelpSystem().displayHelp();

      // Show context sensitive help
      // PlatformUI.getWorkbench().getHelpSystem().displayHelp(
      // "com.qualityeclipse.favorites.favorites_view");

      // Show a specific help page
      PlatformUI.getWorkbench().getHelpSystem().displayHelpResource(
            "/com.qualityeclipse.favorites.help/html/toc.html");

      return null;
   }
}
