package com.qualityeclipse.favorites.model;

public interface FavoritesManagerListener
{
   public void favoritesChanged(FavoritesManagerEvent event);
}
