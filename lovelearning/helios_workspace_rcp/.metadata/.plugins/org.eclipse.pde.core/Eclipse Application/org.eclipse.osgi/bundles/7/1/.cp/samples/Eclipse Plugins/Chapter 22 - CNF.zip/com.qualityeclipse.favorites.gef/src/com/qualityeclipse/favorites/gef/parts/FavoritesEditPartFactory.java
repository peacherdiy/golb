package com.qualityeclipse.favorites.gef.parts;

import org.eclipse.core.resources.IResource;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPartFactory;

import com.qualityeclipse.favorites.gef.model.FavoritesConnection;
import com.qualityeclipse.favorites.model.BasicFavoriteItem;
import com.qualityeclipse.favorites.model.FavoritesManager;

/**
 * The factory responsible for creating edit parts for Favorite model objects.
 */
public class FavoritesEditPartFactory
      implements EditPartFactory
{
   private final boolean editable;

   public FavoritesEditPartFactory(boolean editable) {
      this.editable = editable;
   }
   
   /**
    * Create a new edit part corresponding to the specified Favorites model
    * object
    * 
    * @see org.eclipse.gef.EditPartFactory#createEditPart(org.eclipse.gef.EditPart,
    *      java.lang.Object)
    */
   public EditPart createEditPart(EditPart context, Object model) {

      if (model instanceof FavoritesManager)
         return new FavoritesManagerEditPart((FavoritesManager) model, editable);

      if (model instanceof BasicFavoriteItem)
         return new BasicFavoriteItemEditPart((BasicFavoriteItem) model);

      if (model instanceof IResource)
         return new ResourceEditPart((IResource) model);

      if (model instanceof FavoritesConnection)
         return new FavoriteConnectionEditPart((FavoritesConnection) model);

      throw new IllegalStateException(
            "Couldn't create an edit part for the model object: "
                  + model.getClass().getName());
   }
}