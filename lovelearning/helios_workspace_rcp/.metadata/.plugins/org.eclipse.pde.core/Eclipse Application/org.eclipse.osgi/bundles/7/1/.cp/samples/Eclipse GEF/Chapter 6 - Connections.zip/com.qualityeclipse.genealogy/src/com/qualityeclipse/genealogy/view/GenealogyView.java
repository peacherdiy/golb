package com.qualityeclipse.genealogy.view;

import org.eclipse.draw2d.*;
import org.eclipse.draw2d.geometry.*;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.part.ViewPart;

import com.qualityeclipse.genealogy.figures.*;

import static com.qualityeclipse.genealogy.figures.PersonFigure.MALE;
import static com.qualityeclipse.genealogy.figures.PersonFigure.FEMALE;

/**
 * A example view displaying genealogy using the Draw2D and GEF frameworks
 */
public class GenealogyView extends ViewPart
{
	/**
	 * Add a canvas on which the diagram is rendered and figures representing the various
	 * people and their relationships.
	 * 
	 * @param parent the composite to which the diagram is added
	 */
	private Canvas createDiagram(Composite parent) {

		// Create a root figure and simple layout to contain all other figures
		Figure root = new Figure();
		root.setFont(parent.getFont());
		root.setLayoutManager(new XYLayout());

		// Add the father "Andy"
		IFigure andy = new PersonFigure("Andy", MALE, 1922, 2002);
		andy.add(new NoteFigure("Andy was a\ngood man."));
		root.add(andy, new Rectangle(new Point(10, 10), andy.getPreferredSize()));

		// Add the mother "Betty"
		IFigure betty = new PersonFigure("Betty", FEMALE, 1924, 2006);
		betty.add(new NoteFigure("Betty was a\ngood woman."));
		root.add(betty, new Rectangle(new Point(230, 10), betty.getPreferredSize()));

		// Add the son "Carl"
		IFigure carl = new PersonFigure("Carl", MALE, 1947, -1);
		carl.add(new NoteFigure("Carl is a\ngood man"));
		carl.add(new NoteFigure("He lives in\nBoston, MA"));
		root.add(carl, new Rectangle(new Point(120, 120), carl.getPreferredSize()));

		// Add a "marriage"
		MarriageFigure marriage = new MarriageFigure(1942);
		root.add(marriage, new Rectangle(new Point(145, 35), marriage.getPreferredSize()));

		// Add lines connecting the figures
		root.add(marriage.addParent(andy));
		root.add(marriage.addParent(betty));
		root.add(marriage.addChild(carl));
		
		// Add a "loose" note
		NoteFigure note = new NoteFigure("Smith Family");
		note.setFont(parent.getFont());
		final Dimension noteSize = note.getPreferredSize();
		root.add(note, new Rectangle(new Point(10, 220 - noteSize.height), noteSize));

		// Create the canvas and LightweightSystem
		// and use it to show the root figure in the shell
		Canvas canvas = new Canvas(parent, SWT.DOUBLE_BUFFERED);
		canvas.setBackground(ColorConstants.white);
		LightweightSystem lws = new LightweightSystem(canvas);
		lws.setContents(root);
		return canvas;
	}

	//=============================================
	// Diagram

	public void createPartControl(Composite parent) {
		createDiagram(parent);
	}

	public void setFocus() {
	}

	//=============================================
	// Standalone Shell
	
	/**
	 * The main application entry point
	 */
	public static void main(String[] args) {
		new GenealogyView().run();
	}

	/**
	 * Create, initialize, and run the shell.
	 * Call createDiagram to create the Draw2D diagram.
	 */
	private void run() {
		Shell shell = new Shell(new Display());
		shell.setSize(365, 280);
		shell.setText("Genealogy");
		shell.setLayout(new GridLayout());
		
		Canvas canvas = createDiagram(shell);
		canvas.setLayoutData(new GridData(GridData.FILL_BOTH));
		
		Display display = shell.getDisplay();
		shell.open();
		while (!shell.isDisposed()) {
			while (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}
}
