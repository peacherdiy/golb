package com.qualityeclipse.favorites.wizards;

import org.eclipse.core.runtime.*;

/**
 * Reads a plugin.xml file and build a list of strings that can be extracted
 */
public class ExtractedStringsModel
{
   public ExtractedStringsModel(IPath sourcePath) {
      // Parse file and build map
   }
}
