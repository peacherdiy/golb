package com.qualityeclipse.favorites.model.type;

import org.eclipse.core.resources.IFolder;

import com.qualityeclipse.favorites.model.FavoriteItemFactory;
import com.qualityeclipse.favorites.model.FavoriteItemType;
import com.qualityeclipse.favorites.model.FavoriteResource;
import com.qualityeclipse.favorites.model.IFavoriteItem;

public class FolderFactory extends FavoriteItemFactory
{
   public IFavoriteItem newFavorite(FavoriteItemType type, Object obj) {
      if (!(obj instanceof IFolder))
         return null;
      return new FavoriteResource(type, (IFolder) obj);
   }

   public IFavoriteItem loadFavorite(FavoriteItemType type, String info) {
      return FavoriteResource.loadFavorite(type, info);
   }
}
