package com.qualityeclipse.favorites.properties;

import org.eclipse.jface.preference.ColorSelector;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;

import com.qualityeclipse.favorites.model.BasicFavoriteItem;
import com.qualityeclipse.favorites.model.IFavoriteItem;

/**
 * The Favorites item properties page displayed for a favorites item.
 */
public class FavoriteItemPropertyPage extends FavoriteResourcePropertyPage
{
   private ColorSelector colorSelector;

   /**
    * Creates and returns the SWT control for the customized body of this
    * preference page under the given parent composite. Any subclass returning a
    * <code>Composite</code> object whose <code>Layout</code> has default
    * margins (for example, a <code>GridLayout</code>) are expected to set the
    * margins of this <code>Layout</code> to 0 pixels.
    * 
    * @param parent
    *           the parent composite
    * @return the new control
    */
   protected Control createContents(Composite parent) {
      Composite panel = new Composite(parent, SWT.NONE);
      GridLayout layout = new GridLayout();
      layout.numColumns = 2;
      layout.marginHeight = 0;
      layout.marginWidth = 0;
      panel.setLayout(layout);

      Label label = new Label(panel, SWT.NONE);
      label.setLayoutData(new GridData());
      label.setText("Color of item in Favorites View:");

      colorSelector = new ColorSelector(panel);
      colorSelector.setColorValue(getColorPropertyValue());
      colorSelector.getButton().setLayoutData(new GridData(100, SWT.DEFAULT));

      Composite subpanel = (Composite) super.createContents(panel);
      GridData gridData = new GridData(GridData.FILL_BOTH);
      gridData.horizontalSpan = 2;
      subpanel.setLayoutData(gridData);

      return panel;
   }

   /**
    * Answer the comment associated with the currently selected favorite item
    * 
    * @return the color (not <code>null</code>)
    */
   protected RGB getColorPropertyValue() {
      IFavoriteItem item = (IFavoriteItem) getElement();
      Color color = item.getColor();
      return color.getRGB();
   }

   /**
    * Set the comment associated with the currently selected favorite item
    * 
    * @param rgb
    *           the color (not <code>null</code>)
    */
   protected void setColorPropertyValue(RGB rgb) {
      IFavoriteItem item = (IFavoriteItem) getElement();
      Color color = BasicFavoriteItem.getColor(rgb);
      if (color.equals(BasicFavoriteItem.getDefaultColor()))
         color = null;
      item.setColor(color);
   }

   /**
    * Notifies that the OK button of this page's container has been pressed. In
    * our case, we save the favorites color and call the superclass
    * implementation of this method.
    * 
    * @return <code>false</code> to abort the container's OK processing and
    *         <code>true</code> to allow the OK to happen
    */
   public boolean performOk() {
      setColorPropertyValue(colorSelector.getColorValue());
      return super.performOk();
   }
}
