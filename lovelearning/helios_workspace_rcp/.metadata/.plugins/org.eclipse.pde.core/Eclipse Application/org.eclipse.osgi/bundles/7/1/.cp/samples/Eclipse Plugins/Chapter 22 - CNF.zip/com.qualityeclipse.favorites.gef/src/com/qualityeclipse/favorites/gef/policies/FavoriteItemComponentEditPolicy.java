package com.qualityeclipse.favorites.gef.policies;

import java.util.Iterator;

import org.eclipse.gef.EditPart;
import org.eclipse.gef.commands.Command;
import org.eclipse.gef.commands.CompoundCommand;
import org.eclipse.gef.editpolicies.ComponentEditPolicy;
import org.eclipse.gef.requests.GroupRequest;

import com.qualityeclipse.favorites.gef.commands.FavoriteItemDeleteCommand;
import com.qualityeclipse.favorites.gef.parts.FavoritesManagerEditPart;
import com.qualityeclipse.favorites.model.FavoritesManager;
import com.qualityeclipse.favorites.model.IFavoriteItem;

public class FavoriteItemComponentEditPolicy extends ComponentEditPolicy
{
   protected Command createDeleteCommand(GroupRequest request) {
      FavoritesManager manager =
            ((FavoritesManagerEditPart) getHost().getParent()).getFavoritesManager();
      CompoundCommand delete = new CompoundCommand();
      for (Iterator<?> iterator = request.getEditParts().iterator(); iterator.hasNext();) {
         Object item = ((EditPart) iterator.next()).getModel();
         if (!(item instanceof IFavoriteItem))
            continue;
         delete.add(new FavoriteItemDeleteCommand(manager, ((IFavoriteItem) item)));
      }
      return delete;
   }
}
