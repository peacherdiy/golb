package com.qualityeclipse.favorites.model;

import org.eclipse.core.runtime.IAdapterFactory;

/**
 * In our Favorites product, we cannot modify the implementers of
 * IResource, but we can implement this adapter factory to translate
 * IResource into IFavoriteItem.
 */
public class FavoriteAdapterFactory
      implements IAdapterFactory
{
   private static Class<?>[] SUPPORTED_TYPES = new Class[] { IFavoriteItem.class };

   public Class<?>[] getAdapterList() {
      return SUPPORTED_TYPES;
   }

   @SuppressWarnings("unchecked")
   public Object getAdapter(Object object, Class key) {
      return getAdapterDelegate(object, key);
   }

   private Object getAdapterDelegate(Object object, Class<?> key) {
      if (IFavoriteItem.class.equals(key)) {
         FavoritesManager mgr = FavoritesManager.getManager();
         IFavoriteItem item = mgr.existingFavoriteFor(object);
         if (item == null)
            item = mgr.newFavoriteFor(object);
         return item;
      }
      return null;
   }
}
