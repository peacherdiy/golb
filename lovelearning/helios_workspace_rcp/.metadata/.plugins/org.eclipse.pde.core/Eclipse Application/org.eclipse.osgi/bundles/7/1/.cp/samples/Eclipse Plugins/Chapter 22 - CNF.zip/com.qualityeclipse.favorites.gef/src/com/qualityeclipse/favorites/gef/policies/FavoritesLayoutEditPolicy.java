package com.qualityeclipse.favorites.gef.policies;

import org.eclipse.draw2d.geometry.Rectangle;
import org.eclipse.gef.EditPart;
import org.eclipse.gef.commands.Command;
import org.eclipse.gef.commands.UnexecutableCommand;
import org.eclipse.gef.editpolicies.XYLayoutEditPolicy;
import org.eclipse.gef.requests.CreateRequest;

import com.qualityeclipse.favorites.gef.commands.AdjustConstraintCommand;
import com.qualityeclipse.favorites.gef.commands.FavoriteItemCreateCommand;
import com.qualityeclipse.favorites.gef.parts.AbstractFavoritesNodeEditPart;
import com.qualityeclipse.favorites.model.FavoriteResource;
import com.qualityeclipse.favorites.model.FavoritesManager;

public class FavoritesLayoutEditPolicy extends XYLayoutEditPolicy
{
   protected Command createChangeConstraintCommand(EditPart child, Object constraint) {
      if (child instanceof AbstractFavoritesNodeEditPart) {
         if (constraint instanceof Rectangle) {
            return new AdjustConstraintCommand((AbstractFavoritesNodeEditPart) child,
                  (Rectangle) constraint);
         }
      }
      return UnexecutableCommand.INSTANCE;
   }

   protected Command getCreateCommand(CreateRequest request) {
      if (request.getNewObject() == FavoriteResource.class) {
         FavoritesManager manager = (FavoritesManager) getHost().getModel();
         return new FavoriteItemCreateCommand(manager);
      }
      return UnexecutableCommand.INSTANCE;
   }
}