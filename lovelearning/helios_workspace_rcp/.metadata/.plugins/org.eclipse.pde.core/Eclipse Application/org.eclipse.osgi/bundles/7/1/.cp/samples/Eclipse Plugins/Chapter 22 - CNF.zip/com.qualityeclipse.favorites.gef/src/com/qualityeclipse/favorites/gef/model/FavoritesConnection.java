package com.qualityeclipse.favorites.gef.model;

import org.eclipse.core.resources.IResource;

import com.qualityeclipse.favorites.model.BasicFavoriteItem;

/**
 * A transient object (not persisted) representing a connection between a
 * Favorite item and the target to which it corresponds.
 */
public class FavoritesConnection
{
   private final BasicFavoriteItem source;
   private final IResource target;

   public FavoritesConnection(BasicFavoriteItem item, IResource resource) {
      this.source = item;
      this.target = resource;
   }
   
   public BasicFavoriteItem getBasicFavoriteItem() {
      return source;
   }

   public IResource getResource() {
      return target;
   }
}