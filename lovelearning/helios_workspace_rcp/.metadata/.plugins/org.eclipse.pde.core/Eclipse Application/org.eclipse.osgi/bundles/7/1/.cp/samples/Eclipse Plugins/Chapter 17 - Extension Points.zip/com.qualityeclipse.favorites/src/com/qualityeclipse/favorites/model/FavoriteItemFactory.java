package com.qualityeclipse.favorites.model;

/**
 * A common superclass for all factories that instantiate favorite items.
 */
public abstract class FavoriteItemFactory
{
   /**
    * Answer a new favorite item wrappering the specified object
    * 
    * @param type
    *           the favorite item type
    * @param obj
    *           the object to be wrappered
    * @return the favorite item or <code>null</code> if it could not be
    *         wrappered by this type
    */
   public abstract IFavoriteItem newFavorite(FavoriteItemType type, Object obj);

   /**
    * Reinstantiate a favorite item from stored information
    * 
    * @param type
    *           the favorite item type
    * @param info
    *           the stored information
    * @return the favorite item or <code>null</code> if it could not be
    *         reinstantiated
    */
   public abstract IFavoriteItem loadFavorite(FavoriteItemType type, String info);

   /**
    * Dispose of any OS resources before being discarded. Subclasses may
    * override.
    */
   public void dispose() {
      // Nothing to do... subclasses may override.
   }
}
